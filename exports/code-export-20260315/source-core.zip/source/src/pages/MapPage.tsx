import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { requestSupplementPlaces } from '../api/service'
import type { ApiRecommendationItem, ApiSupplementPlace } from '../api/types'
import FeedView from '../components/FeedView'
import MapCanvas from '../components/MapCanvas'
import RecommendationPanel from '../components/RecommendationPanel'
import { campusMap, campuses, defaultCampusId } from '../data/campuses'
import { restaurants } from '../data/restaurants'
import { trackEvent } from '../lib/analytics'
import { buildPreferencePrompt, getTastePreference } from '../lib/me'
import { openAmapNavigation } from '../lib/navigation'
import { buildRankedRecommendations, selectNextBatch } from '../lib/recommendation'
import { parseSceneQuery, toSearchParams, type SceneQueryState } from '../lib/scene'
import type {
  MealTime,
  OpenHourSlot,
  PeopleCount,
  Restaurant,
  RestaurantWithRecommendation,
  Urgency,
} from '../types/domain'

const peopleLabels: Record<PeopleCount, string> = {
  solo: '一个人',
  smallGroup: '2-3 人',
  group: '4 人以上',
}

const mealLabels: Record<MealTime, string> = {
  breakfast: '早餐',
  lunch: '午餐',
  dinner: '晚餐',
  lateNight: '宵夜',
}

const urgencyLabels: Record<Urgency, string> = {
  rush: '很赶',
  normal: '正常',
  relax: '慢慢吃',
}

const mapToApiItem = (item: RestaurantWithRecommendation): ApiRecommendationItem => ({
  place: {
    id: item.restaurant.id,
    name: item.restaurant.name,
    type: item.restaurant.type,
    campusId: item.restaurant.campusId,
    location: item.restaurant.location,
    cuisines: item.restaurant.cuisines,
    tags: item.restaurant.tags,
    rating: item.restaurant.rating,
    avgPrice: item.restaurant.avgPrice,
    vibeLine: item.restaurant.vibeLine,
    signatureDishes: item.restaurant.signatureDishes,
    trustSignals: {
      keywords: item.restaurant.trustSignals.keywords,
      revisitRate30d: item.restaurant.trustSignals.revisitRate30d,
      aiSummary: item.restaurant.trustSignals.aiSummary,
    },
  },
  recommendation: item.recommendation,
  distanceKm: item.distanceKm,
  openNow: item.openNow,
})

const bumpInterest = (
  item: ApiRecommendationItem,
  previous: Record<string, number>,
): Record<string, number> => {
  const next = { ...previous }
  for (const label of [...item.place.cuisines, ...item.place.tags]) {
    next[label] = (next[label] ?? 0) + 1.1
  }
  return next
}

const sceneSignature = (scene: SceneQueryState): string =>
  [
    scene.campusId,
    scene.people,
    scene.mealTime,
    scene.urgency,
    scene.freeText,
    scene.cuisine,
    scene.budget,
    scene.distance,
  ].join('|')

const includesAny = (texts: string[], keywords: string[]): boolean =>
  keywords.some((keyword) => texts.some((text) => text.includes(keyword)))

const cuisineAliasMap: Record<string, string[]> = {
  安徽菜: ['安徽菜', '徽菜'],
  徽菜: ['徽菜', '安徽菜'],
  上海菜: ['上海菜', '本帮菜', '江浙菜'],
  本帮菜: ['本帮菜', '上海菜'],
  江浙菜: ['江浙菜', '本帮菜', '上海菜'],
  川菜: ['川菜', '川味', '麻辣'],
  湘菜: ['湘菜', '湘味'],
  粤菜: ['粤菜', '广式'],
  火锅: ['火锅', '锅底'],
  烧烤: ['烧烤', '烤串'],
  麻辣烫: ['麻辣烫', '冒菜'],
  轻食: ['轻食', '沙拉'],
  面食: ['面食', '面馆'],
  甜品: ['甜品', '糖水'],
}

const knownCuisineTerms = Array.from(new Set(Object.values(cuisineAliasMap).flat()))

const tabooAliasMap: Record<string, string[]> = {
  不吃辣: ['辣', '麻辣', '川味'],
  不吃香菜: ['香菜'],
  素食: ['牛肉', '鸡', '鸭', '海鲜', '羊肉'],
  不吃葱蒜: ['葱', '蒜'],
  不吃海鲜: ['海鲜', '虾', '鱼'],
}

const tasteAliasMap: Record<string, string[]> = {
  重口: ['重口', '下饭', '川味', '湘菜', '麻辣'],
  清淡: ['清淡', '轻食', '汤面', '粥'],
  甜食: ['甜品', '糖水', '甜口'],
  咸香: ['咸香', '下饭', '烧烤'],
  酸辣: ['酸辣', '麻辣'],
  汤面: ['面食', '汤面', '粉面'],
  烧烤: ['烧烤', '烤串', '夜宵'],
}

const collectCuisineKeywords = (cuisine: string, freeText: string): string[] => {
  const normalizedCuisine = cuisine.trim()
  const normalizedText = freeText.trim()

  const splitTokens = `${normalizedCuisine} ${normalizedText}`
    .split(/[\s,，。！!？?、/]+/g)
    .map((token) => token.trim())
    .filter((token) => token.length >= 2)

  const containedKeywords = knownCuisineTerms.filter(
    (term) => normalizedCuisine.includes(term) || normalizedText.includes(term),
  )

  const expanded = [...splitTokens, ...containedKeywords].flatMap((token) => cuisineAliasMap[token] ?? [token])

  return Array.from(
    new Set(
      expanded
        .map((token) => token.trim())
        .filter((token) => token.length >= 2)
        .slice(0, 12),
    ),
  )
}

const cuisineMatchScore = (restaurant: Restaurant, keywords: string[]): number => {
  if (keywords.length === 0) {
    return 0
  }

  const searchable = [
    restaurant.name,
    ...restaurant.tags,
    ...restaurant.cuisines,
    restaurant.trustSignals.aiSummary,
  ]

  let score = 0
  for (const keyword of keywords) {
    if (restaurant.name.includes(keyword)) {
      score += 4
    }
    if (restaurant.cuisines.some((item) => item.includes(keyword))) {
      score += 5
    }
    if (restaurant.tags.some((item) => item.includes(keyword))) {
      score += 5
    }
    if (restaurant.trustSignals.aiSummary.includes(keyword)) {
      score += 3
    }
    if (searchable.some((item) => item.includes(keyword))) {
      score += 1
    }
  }

  return score
}

const buildKeywordBoost = (keywords: string[]): Record<string, number> =>
  keywords.reduce<Record<string, number>>((acc, keyword) => {
    acc[keyword] = (acc[keyword] ?? 0) + 3.4
    return acc
  }, {})

const mergeBoost = (
  primary: Record<string, number>,
  secondary: Record<string, number>,
): Record<string, number> => {
  const merged = { ...primary }
  for (const [key, value] of Object.entries(secondary)) {
    merged[key] = (merged[key] ?? 0) + value
  }
  return merged
}

const parseBudgetLimit = (raw: string): number | null => {
  const input = raw.trim()
  if (!input) {
    return null
  }

  const matched = input.match(/(\d{1,3})/)
  if (!matched) {
    return null
  }

  const value = Number(matched[1])
  if (!Number.isFinite(value) || value <= 0) {
    return null
  }

  return value
}

const parseDistanceToMinutes = (raw: string): number | null => {
  const input = raw.trim()
  if (!input) {
    return null
  }

  const numberMatch = input.match(/(\d{1,3})/)
  if (!numberMatch) {
    return null
  }

  const value = Number(numberMatch[1])
  if (!Number.isFinite(value) || value <= 0) {
    return null
  }

  if (input.includes('公里') || input.toLowerCase().includes('km')) {
    return Math.round(value * 17)
  }

  if (input.includes('米') || input.toLowerCase().includes('m')) {
    return Math.max(6, Math.round(value / 80))
  }

  return value
}

const inferPriceLevel = (avgPrice: number): 1 | 2 | 3 | 4 => {
  if (avgPrice <= 20) {
    return 1
  }
  if (avgPrice <= 40) {
    return 2
  }
  if (avgPrice <= 70) {
    return 3
  }
  return 4
}

const fullWeek = (start: string, end: string): OpenHourSlot[] =>
  ([0, 1, 2, 3, 4, 5, 6] as const).map((day) => ({ day, start, end }))

const toSupplementRestaurant = (place: ApiSupplementPlace, index: number, cuisine: string): Restaurant => {
  const seed = `${place.name}-${place.lng}-${place.lat}-${index}`
  const safeId = seed
    .replace(/[^a-zA-Z0-9\u4e00-\u9fa5]+/g, '-')
    .replace(/-+/g, '-')
    .toLowerCase()

  const keywords = Array.from(new Set(place.tags.filter((item) => item.trim().length > 0)))

  return {
    id: `ai-${safeId}`,
    name: place.name,
    campusId: place.campusId,
    type: 'restaurant',
    location: { lng: place.lng, lat: place.lat },
    cuisines: Array.from(new Set([cuisine, ...keywords].filter((item) => item.length > 0))).slice(0, 3),
    priceLevel: inferPriceLevel(place.avgPrice),
    avgPrice: place.avgPrice,
    rating: place.rating,
    reviewCount: 96 + index * 14,
    openHours: fullWeek('10:30', '22:00'),
    tags: keywords,
    signatureDishes:
      place.signatureDishes.length > 0
        ? place.signatureDishes
        : ['招牌臭鳜鱼', '笋干烧肉'],
    address: place.address,
    vibeLine: place.aiSummary,
    trustSignals: {
      keywords: keywords.slice(0, 3),
      revisitRate30d: place.revisitRate30d,
      aiSummary: place.aiSummary,
    },
    mealServiceSpeed: 'normal',
  }
}

export default function MapPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const scene = useMemo(() => parseSceneQuery(searchParams), [searchParams])
  const campus = campusMap[scene.campusId] ?? campusMap[defaultCampusId]
  const sceneRef = useRef(scene)

  const [interestBoost, setInterestBoost] = useState<Record<string, number>>({})
  const [seenIds, setSeenIds] = useState<Set<string>>(new Set())
  const [batch, setBatch] = useState<ApiRecommendationItem[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [openNowOnly, setOpenNowOnly] = useState(false)
  const [maxWalkMinutes, setMaxWalkMinutes] = useState(25)
  const [supplementRestaurants, setSupplementRestaurants] = useState<Restaurant[]>([])
  const preferences = useMemo(() => getTastePreference(scene.campusId), [scene.campusId])
  const preferencePrompt = useMemo(() => buildPreferencePrompt(preferences), [preferences])
  const effectiveFreeText = useMemo(
    () => [scene.freeText.trim(), preferencePrompt].filter((item) => item.length > 0).join('；'),
    [preferencePrompt, scene.freeText],
  )

  const updateScene = useCallback(
    (patch: Partial<SceneQueryState>): void => {
      const next = { ...sceneRef.current, ...patch }
      setSearchParams(toSearchParams(next), { replace: true })
    },
    [setSearchParams],
  )

  useEffect(() => {
    sceneRef.current = scene
  }, [scene])

  const scopedRestaurants = useMemo(
    () => restaurants.filter((item) => item.campusId === campus.id),
    [campus.id],
  )

  const cuisineKeywords = useMemo(
    () => collectCuisineKeywords(scene.cuisine, effectiveFreeText),
    [effectiveFreeText, scene.cuisine],
  )

  const tabooKeywords = useMemo(
    () =>
      Array.from(new Set(preferences.tabooTags.flatMap((item) => tabooAliasMap[item] ?? []))).filter(
        (item) => item.length > 0,
      ),
    [preferences.tabooTags],
  )

  const preferenceTasteKeywords = useMemo(
    () =>
      Array.from(new Set(preferences.tasteTags.flatMap((item) => tasteAliasMap[item] ?? []))).filter(
        (item) => item.length > 0,
      ),
    [preferences.tasteTags],
  )

  const baseCuisineMatchedCount = useMemo(
    () => scopedRestaurants.filter((item) => cuisineMatchScore(item, cuisineKeywords) > 0).length,
    [cuisineKeywords, scopedRestaurants],
  )

  useEffect(() => {
    let cancelled = false

    if (cuisineKeywords.length === 0 || baseCuisineMatchedCount > 0) {
      const timer = window.setTimeout(() => {
        if (!cancelled) {
          setSupplementRestaurants([])
        }
      }, 0)
      return () => {
        cancelled = true
        window.clearTimeout(timer)
      }
    }

    const queryCuisine = scene.cuisine.trim() || cuisineKeywords[0]
    const timer = window.setTimeout(async () => {
      try {
        const data = await requestSupplementPlaces(queryCuisine, 2)
        if (cancelled) {
          return
        }

        const nextPlaces = (data.places ?? []).map((item, index) =>
          toSupplementRestaurant(item, index, queryCuisine),
        )

        setSupplementRestaurants(nextPlaces)
      } catch {
        if (!cancelled) {
          setSupplementRestaurants([])
        }
      }
    }, 250)

    return () => {
      cancelled = true
      window.clearTimeout(timer)
    }
  }, [baseCuisineMatchedCount, cuisineKeywords, scene.cuisine])

  const workingRestaurants = useMemo(
    () => [...scopedRestaurants, ...supplementRestaurants],
    [scopedRestaurants, supplementRestaurants],
  )

  const sceneFilteredRestaurants = useMemo(() => {
    let candidates = workingRestaurants

    if (tabooKeywords.length > 0) {
      const filtered = candidates.filter(
        (item) => !includesAny([...item.cuisines, ...item.tags, item.trustSignals.aiSummary], tabooKeywords),
      )
      if (filtered.length >= 3) {
        candidates = filtered
      }
    }

    if (scene.mealTime === 'breakfast') {
      const breakfastPool = candidates.filter((item) =>
        includesAny([...item.cuisines, ...item.tags], ['早餐', '粥', '热干面', '面食']),
      )
      if (breakfastPool.length >= 3) {
        candidates = breakfastPool
      }
    }

    if (scene.mealTime === 'lateNight') {
      const lateNightPool = candidates.filter((item) => includesAny(item.tags, ['夜宵', '晚课后']))
      if (lateNightPool.length >= 3) {
        candidates = lateNightPool
      }
    }

    if (scene.urgency === 'rush') {
      const quickPool = candidates.filter((item) => item.mealServiceSpeed === 'fast')
      if (quickPool.length >= 3) {
        candidates = quickPool
      }
    }

    if (scene.people === 'group') {
      const groupPool = candidates.filter((item) => includesAny(item.tags, ['聚餐', '拼桌', '朋友']))
      if (groupPool.length >= 3) {
        candidates = groupPool
      }
    }

    return candidates
  }, [scene.mealTime, scene.people, scene.urgency, tabooKeywords, workingRestaurants])

  const cuisineMatchedRestaurants = useMemo(() => {
    if (cuisineKeywords.length === 0) {
      return sceneFilteredRestaurants
    }

    const scored = sceneFilteredRestaurants
      .map((item) => ({ item, score: cuisineMatchScore(item, cuisineKeywords) }))
      .filter((entry) => entry.score > 0)
      .sort((a, b) => b.score - a.score)

    if (scored.length === 0) {
      return sceneFilteredRestaurants
    }

    return scored.map((entry) => entry.item)
  }, [cuisineKeywords, sceneFilteredRestaurants])

  const keywordBoost = useMemo(
    () => mergeBoost(buildKeywordBoost(cuisineKeywords), buildKeywordBoost(preferenceTasteKeywords)),
    [cuisineKeywords, preferenceTasteKeywords],
  )

  const baseCandidates = useMemo(
    () => buildRankedRecommendations(cuisineMatchedRestaurants, scene, campus, keywordBoost),
    [campus, cuisineMatchedRestaurants, keywordBoost, scene],
  )

  const boostedCandidates = useMemo(
    () =>
      buildRankedRecommendations(
        cuisineMatchedRestaurants,
        scene,
        campus,
        mergeBoost(keywordBoost, interestBoost),
      ),
    [campus, cuisineMatchedRestaurants, interestBoost, keywordBoost, scene],
  )

  const budgetLimit = useMemo(
    () => parseBudgetLimit(scene.budget || effectiveFreeText),
    [effectiveFreeText, scene.budget],
  )

  const parsedDistanceLimit = useMemo(
    () => parseDistanceToMinutes(scene.distance || ''),
    [scene.distance],
  )

  const effectiveMaxWalkMinutes = useMemo(() => {
    if (!parsedDistanceLimit) {
      return maxWalkMinutes
    }
    return Math.min(maxWalkMinutes, parsedDistanceLimit)
  }, [maxWalkMinutes, parsedDistanceLimit])

  const filteredCandidates = useMemo(
    () =>
      baseCandidates.filter(
        (item) =>
          (!openNowOnly || item.openNow) &&
          item.recommendation.walkMinutes <= effectiveMaxWalkMinutes &&
          (budgetLimit === null || item.restaurant.avgPrice <= budgetLimit),
      ),
    [baseCandidates, budgetLimit, effectiveMaxWalkMinutes, openNowOnly],
  )

  const filteredBoostedCandidates = useMemo(
    () =>
      boostedCandidates.filter(
        (item) =>
          (!openNowOnly || item.openNow) &&
          item.recommendation.walkMinutes <= effectiveMaxWalkMinutes &&
          (budgetLimit === null || item.restaurant.avgPrice <= budgetLimit),
      ),
    [boostedCandidates, budgetLimit, effectiveMaxWalkMinutes, openNowOnly],
  )

  const querySignature = useMemo(() => sceneSignature(scene), [scene])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setInterestBoost({})
  }, [querySignature])

  useEffect(() => {
    const initial = selectNextBatch(filteredCandidates, new Set(), new Set(), 5)
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setBatch(initial.map(mapToApiItem))
    setSeenIds(new Set(initial.map((item) => item.restaurant.id)))
    setActiveId(initial[0]?.restaurant.id ?? null)
  }, [filteredCandidates, querySignature])

  const handleRefreshBatch = (): void => {
    const previousIds = new Set(batch.map((item) => item.place.id))
    const next = selectNextBatch(filteredBoostedCandidates, previousIds, seenIds, 5)

    if (next.length === 0) {
      return
    }

    const nextSeen = new Set([...Array.from(seenIds), ...next.map((item) => item.restaurant.id)])
    const newCount = next.filter((item) => !seenIds.has(item.restaurant.id)).length

    setBatch(next.map(mapToApiItem))
    setSeenIds(nextSeen)
    setActiveId(next[0]?.restaurant.id ?? null)
    trackEvent('batch_refresh', {
      campusId: scene.campusId,
      newCount,
      total: next.length,
    })
  }

  const handleOpenDetail = (item: ApiRecommendationItem): void => {
    trackEvent('card_open_detail', {
      id: item.place.id,
      campusId: item.place.campusId,
    })
    setInterestBoost((prev) => bumpInterest(item, prev))
  }

  const handleNavigateFromList = (item: ApiRecommendationItem): void => {
    setActiveId(item.place.id)
    if (sceneRef.current.view !== 'map') {
      updateScene({ view: 'map' })
    }

    openAmapNavigation(
      {
        lng: item.place.location.lng,
        lat: item.place.location.lat,
        name: item.place.name,
      },
      {
        lng: campus.center.lng,
        lat: campus.center.lat,
        name: `${campus.shortName}校区`,
      },
    )
  }

  const searchString = toSearchParams(scene).toString()
  const mapPoints = useMemo(
    () =>
      batch.map((item) => ({
        id: item.place.id,
        name: item.place.name,
        type: item.place.type,
        location: item.place.location,
        reason: item.recommendation.reason,
      })),
    [batch],
  )

  return (
    <div className="map-page">
      <aside className="map-sidebar">
        <section className="panel sidebar-glass-card map-scene-card">
          <h2>校区场景</h2>
          <div className="compact-grid compact-grid--scene">
            <label className="compact-field compact-field--wide">
              校区
              <select onChange={(event) => updateScene({ campusId: event.target.value })} value={scene.campusId}>
                {campuses.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
            </label>

            <section className="segment-row compact-field--wide" aria-label="时段选择">
              <p className="segment-row__label">时段</p>
              <div className="segment-row__control">
                {(Object.keys(mealLabels) as MealTime[]).map((key) => (
                  <button
                    className={scene.mealTime === key ? 'segment-row__item segment-row__item--active' : 'segment-row__item'}
                    key={key}
                    onClick={() => updateScene({ mealTime: key })}
                    type="button"
                  >
                    {mealLabels[key]}
                  </button>
                ))}
              </div>
            </section>

            <section className="segment-row compact-field--wide" aria-label="人数选择">
              <p className="segment-row__label">人数</p>
              <div className="segment-row__control segment-row__control--triple">
                {(Object.keys(peopleLabels) as PeopleCount[]).map((key) => (
                  <button
                    className={scene.people === key ? 'segment-row__item segment-row__item--active' : 'segment-row__item'}
                    key={key}
                    onClick={() => updateScene({ people: key })}
                    type="button"
                  >
                    {peopleLabels[key]}
                  </button>
                ))}
              </div>
            </section>

            <section className="segment-row compact-field--wide" aria-label="节奏选择">
              <p className="segment-row__label">节奏</p>
              <div className="segment-row__control segment-row__control--triple">
                {(Object.keys(urgencyLabels) as Urgency[]).map((key) => (
                  <button
                    className={scene.urgency === key ? 'segment-row__item segment-row__item--active' : 'segment-row__item'}
                    key={key}
                    onClick={() => updateScene({ urgency: key })}
                    type="button"
                  >
                    {urgencyLabels[key]}
                  </button>
                ))}
              </div>
            </section>
          </div>

          <div className="scene-links">
            <button
              className={openNowOnly ? 'scene-link scene-link--active' : 'scene-link'}
              onClick={() => setOpenNowOnly((prev) => !prev)}
              type="button"
            >
              <span className="scene-link__text">只看营业</span>
              <span className="scene-link__bar" />
            </button>
            <span aria-hidden="true" className="scene-links__divider" />
            <button className="scene-link" onClick={handleRefreshBatch} type="button">
              <span className="scene-link__text">换几家试试</span>
              <span className="scene-link__bar" />
            </button>
            <span aria-hidden="true" className="scene-links__divider" />
            <Link className="scene-link" to={`/community?${searchString}`}>
              <span className="scene-link__text">看同学说</span>
              <span className="scene-link__bar" />
            </Link>
          </div>

          <div className="quick-filters quick-filters--tight">
            <label>
              最远步行 {effectiveMaxWalkMinutes} 分钟
              <input
                max={40}
                min={8}
                onChange={(event) => setMaxWalkMinutes(Number(event.target.value))}
                step={1}
                type="range"
                value={maxWalkMinutes}
              />
            </label>
          </div>

          <div className="toggle-row toggle-row--tight">
            <button
              className={scene.view === 'map' ? 'toggle-btn toggle-btn--active' : 'toggle-btn'}
              onClick={() => updateScene({ view: 'map' })}
              type="button"
            >
              地图视图
            </button>
            <button
              className={scene.view === 'feed' ? 'toggle-btn toggle-btn--active' : 'toggle-btn'}
              onClick={() => updateScene({ view: 'feed' })}
              type="button"
            >
              图片流视图
            </button>
          </div>

        </section>

        <section className="map-sidebar-list" aria-label="推荐餐厅列表">
          <RecommendationPanel
            activeId={activeId}
            items={batch}
            onActive={setActiveId}
            onNavigate={handleNavigateFromList}
            onOpenDetail={handleOpenDetail}
            search={searchString}
          />
        </section>
      </aside>

      <section className="map-main">
        {scene.view === 'map' ? (
          <MapCanvas
            activeId={activeId}
            center={campus.center}
            onSelect={setActiveId}
            points={mapPoints}
          />
        ) : (
          <FeedView items={batch} onNavigate={handleNavigateFromList} onOpenDetail={handleOpenDetail} search={searchString} />
        )}
      </section>
    </div>
  )
}

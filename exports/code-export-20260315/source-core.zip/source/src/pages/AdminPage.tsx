import { useState } from 'react'
import { getModerationQueue, moderateQueueItem } from '../api/service'
import type { ApiModerationItem } from '../api/types'

export default function AdminPage() {
  const [adminKey, setAdminKey] = useState('')
  const [items, setItems] = useState<ApiModerationItem[]>([])
  const [tip, setTip] = useState('')
  const [loading, setLoading] = useState(false)

  const loadQueue = async (): Promise<void> => {
    setLoading(true)
    try {
      const data = await getModerationQueue(adminKey)
      setItems(data.items)
      setTip(`待审核 ${data.items.length} 条`)
    } catch {
      setTip('拉取审核队列失败，请检查 Admin Key。')
    } finally {
      setLoading(false)
    }
  }

  const handleAction = async (id: string, action: 'approve' | 'reject'): Promise<void> => {
    try {
      await moderateQueueItem(adminKey, id, action)
      setItems((prev) => prev.filter((item) => item.id !== id))
      setTip(`已${action === 'approve' ? '通过' : '拒绝'} 1 条`)
    } catch {
      setTip('审核操作失败。')
    }
  }

  return (
    <section className="community-page">
      <header>
        <h1>运营审核台</h1>
        <p>用于处理评论、帖子、评论回复、众包上架等待审核内容。</p>
      </header>

      <article className="community-card">
        <label className="scene-form__block" htmlFor="admin-key">
          <span>Admin Key</span>
          <input
            id="admin-key"
            onChange={(event) => setAdminKey(event.target.value)}
            placeholder="默认: shike-admin"
            value={adminKey}
          />
        </label>
        <div className="detail-actions">
          <button onClick={() => void loadQueue()} type="button">
            刷新队列
          </button>
        </div>
        {loading ? <p>加载中...</p> : null}
        {tip ? <p className="detail-tip">{tip}</p> : null}
      </article>

      <div className="community-list">
        {items.map((item) => (
          <article className="community-card" key={item.id}>
            <p><strong>{item.targetType}</strong> · {item.targetId}</p>
            <p>{item.reason}</p>
            <p>创建时间：{new Date(item.createdAt).toLocaleString()}</p>
            <div className="detail-actions">
              <button onClick={() => void handleAction(item.id, 'approve')} type="button">
                通过
              </button>
              <button onClick={() => void handleAction(item.id, 'reject')} type="button">
                拒绝
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}


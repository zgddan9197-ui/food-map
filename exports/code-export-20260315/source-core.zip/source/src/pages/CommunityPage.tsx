import { useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { communityMoments, type CommunityMoment } from '../data/community'

interface DraftMoment {
  restaurantName: string
  content: string
  image: string
}

const defaultImage =
  'https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=900&q=80'

export default function CommunityPage() {
  const [searchParams] = useSearchParams()
  const search = searchParams.toString()

  const [openComposer, setOpenComposer] = useState(false)
  const [draft, setDraft] = useState<DraftMoment>({
    restaurantName: '',
    content: '',
    image: '',
  })
  const [moments, setMoments] = useState<CommunityMoment[]>(communityMoments)

  const orderedMoments = useMemo(
    () =>
      [...moments].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [moments],
  )

  const submitMoment = (): void => {
    if (!draft.restaurantName.trim() || !draft.content.trim()) {
      return
    }

    const newMoment: CommunityMoment = {
      id: `local-${Date.now()}`,
      author: '你',
      restaurantId: '',
      restaurantName: draft.restaurantName.trim(),
      content: draft.content.trim(),
      image: draft.image.trim() || defaultImage,
      createdAt: new Date().toISOString(),
    }

    setMoments((prev) => [newMoment, ...prev])
    setDraft({ restaurantName: '', content: '', image: '' })
    setOpenComposer(false)
  }

  return (
    <section className="community-page">
      <header>
        <h1>社区广场</h1>
        <p>真实的同学，真实的饭</p>
      </header>

      <div className="community-waterfall">
        {orderedMoments.map((post) => (
          <article className="community-moment" key={post.id}>
            <img alt={post.restaurantName} src={post.image} />
            <div className="community-moment__body">
              <p className="community-card__meta">
                <strong>{post.author}</strong>
                <span>{new Date(post.createdAt).toLocaleDateString()}</span>
              </p>
              <h2>{post.restaurantName}</h2>
              <p>“{post.content}”</p>
              {post.restaurantId ? (
                <p className="community-card__restaurant">
                  <Link to={`/detail/${post.restaurantId}?${search}`}>去看这家</Link>
                </p>
              ) : null}
            </div>
          </article>
        ))}
      </div>

      <button
        aria-label="发布推荐"
        className="community-fab"
        onClick={() => setOpenComposer(true)}
        type="button"
      >
        +
      </button>

      {openComposer ? (
        <div className="composer-mask" role="dialog" aria-modal="true">
          <div className="composer-card">
            <h2>发布推荐</h2>
            <label className="scene-form__block" htmlFor="composer-restaurant">
              <span>店名</span>
              <input
                id="composer-restaurant"
                onChange={(event) => setDraft((prev) => ({ ...prev, restaurantName: event.target.value }))}
                placeholder="例如：珞珈面馆"
                value={draft.restaurantName}
              />
            </label>
            <label className="scene-form__block" htmlFor="composer-content">
              <span>评价</span>
              <textarea
                id="composer-content"
                maxLength={180}
                onChange={(event) => setDraft((prev) => ({ ...prev, content: event.target.value }))}
                placeholder="例如：真的绝绝子！面香很稳，价格也友好。"
                value={draft.content}
              />
            </label>
            <label className="scene-form__block" htmlFor="composer-image">
              <span>一张图（图片 URL，可选）</span>
              <input
                id="composer-image"
                onChange={(event) => setDraft((prev) => ({ ...prev, image: event.target.value }))}
                placeholder="https://..."
                value={draft.image}
              />
            </label>
            <div className="detail-actions">
              <button onClick={submitMoment} type="button">
                发布
              </button>
              <button onClick={() => setOpenComposer(false)} type="button">
                取消
              </button>
            </div>
          </div>
        </div>
      ) : null}

      <footer className="community-footer">
        <Link to={search ? `/map?${search}` : '/map'}>去地图找一家</Link>
      </footer>
    </section>
  )
}

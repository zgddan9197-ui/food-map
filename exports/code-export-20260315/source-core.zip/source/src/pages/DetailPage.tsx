import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useLocation, useParams } from 'react-router-dom'
import { campusMap } from '../data/campuses'
import { restaurants } from '../data/restaurants'
import { printEventSummary, trackEvent } from '../lib/analytics'
import { calcDistanceKm, estimateWalkMinutes, formatDistance } from '../lib/geo'
import { appendReviewEntry, getFavoriteEntries, getReviewEntries, saveFavoriteEntries } from '../lib/me'
import { openAmapNavigation } from '../lib/navigation'
import { formatBusinessHours, isOpenNow } from '../lib/time'

interface CommentItem {
  id: string
  nickname: string
  createdAt: string
  tags: string[]
  text: string
  likeCount: number
  avatarTone: string
  avatarInk: string
}

const presetTagOptions = ['好吃', '量大', '出餐快', '性价比高', '环境好', '回头率高', '踩雷', '一般']
const peerNicknames = ['小林', '阿沫', '浩子', '卷卷', '可可', '阿泽', '七七', '木木']

const toggleTag = (source: string[], tag: string): string[] =>
  source.includes(tag) ? source.filter((item) => item !== tag) : [...source, tag]

const hashText = (input: string): number => {
  let hash = 0
  for (let index = 0; index < input.length; index += 1) {
    hash = (hash * 31 + input.charCodeAt(index)) >>> 0
  }
  return hash
}

const makeAvatarTone = (seed: string): { avatarTone: string; avatarInk: string } => {
  const hue = hashText(seed) % 360
  return {
    avatarTone: `hsl(${hue} 72% 86%)`,
    avatarInk: `hsl(${hue} 58% 28%)`,
  }
}

const makeSeedComments = (restaurant: (typeof restaurants)[number]): CommentItem[] => {
  const keyword = restaurant.trustSignals.keywords[0] ?? restaurant.tags[0] ?? '好吃'
  const tagA = restaurant.tags[0] ?? '好吃'
  const tagB = restaurant.tags[1] ?? '出餐快'
  const tagC = restaurant.tags[2] ?? '回头率高'

  const base = [
    {
      nickname: '小林',
      tags: [tagA, '好吃'],
      text: `点 ${restaurant.signatureDishes[0]} 基本不会错，味道很稳，${keyword}这点我也同意。`,
      likeCount: 42,
      hoursAgo: 3,
    },
    {
      nickname: '阿沫',
      tags: [tagB, '性价比高'],
      text: `课间来吃很省心，出餐节奏友好，人均控制得住。`,
      likeCount: 29,
      hoursAgo: 9,
    },
    {
      nickname: '浩子',
      tags: [tagC, '量大'],
      text: `和室友一起点两份就很够，晚上来人也不少。`,
      likeCount: 21,
      hoursAgo: 20,
    },
    {
      nickname: '卷卷',
      tags: ['一般'],
      text: `整体还行，主打一个离学校近，赶时间时挺实用。`,
      likeCount: 15,
      hoursAgo: 31,
    },
  ]

  return base.map((item, index) => {
    const style = makeAvatarTone(`${restaurant.id}-${item.nickname}-${index}`)
    return {
      id: `seed-${restaurant.id}-${index}`,
      nickname: item.nickname,
      createdAt: new Date(Date.now() - item.hoursAgo * 60 * 60 * 1000).toISOString(),
      tags: item.tags,
      text: item.text,
      likeCount: item.likeCount,
      avatarTone: style.avatarTone,
      avatarInk: style.avatarInk,
    }
  })
}

const copyText = async (value: string): Promise<void> => {
  if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value)
    return
  }

  const input = document.createElement('textarea')
  input.value = value
  input.style.position = 'fixed'
  input.style.opacity = '0'
  document.body.appendChild(input)
  input.select()
  document.execCommand('copy')
  document.body.removeChild(input)
}

const formatCommentTime = (value: string): string =>
  new Date(value).toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })

export default function DetailPage() {
  const { id } = useParams()
  const location = useLocation()
  const startAtRef = useRef(0)
  const toastTimerRef = useRef<number | null>(null)
  const reviewInputRef = useRef<HTMLTextAreaElement | null>(null)
  const reviewSectionRef = useRef<HTMLElement | null>(null)
  const [reviewText, setReviewText] = useState('')
  const [selectedTags, setSelectedTags] = useState<string[]>(['好吃', '回头率高'])
  const [customTagInput, setCustomTagInput] = useState('')
  const [customTags, setCustomTags] = useState<string[]>([])
  const [showCustomInput, setShowCustomInput] = useState(false)
  const [reviewTip, setReviewTip] = useState('')
  const [liked, setLiked] = useState(false)
  const [favoriteEntries, setFavoriteEntries] = useState(() => getFavoriteEntries())
  const [reviewEntries, setReviewEntries] = useState(() => getReviewEntries())
  const [lastSelfReviewId, setLastSelfReviewId] = useState<string | null>(null)
  const [commentsExpanded, setCommentsExpanded] = useState(false)
  const [sharePanelOpen, setSharePanelOpen] = useState(false)
  const [toastText, setToastText] = useState('')

  const restaurant = useMemo(() => restaurants.find((item) => item.id === id), [id])
  const campus = restaurant ? campusMap[restaurant.campusId] : null

  const baseLikeCount = useMemo(
    () => (restaurant ? Math.max(16, Math.round(restaurant.reviewCount * 0.35)) : 16),
    [restaurant],
  )
  const baseCollectCount = useMemo(
    () => (restaurant ? Math.max(10, Math.round(restaurant.reviewCount * 0.2)) : 10),
    [restaurant],
  )

  const seedComments = useMemo(
    () => (restaurant ? makeSeedComments(restaurant) : []),
    [restaurant],
  )

  const userComments = useMemo(() => {
    if (!restaurant) {
      return [] as CommentItem[]
    }

    return reviewEntries
      .filter((entry) => entry.placeId === restaurant.id)
      .map((entry, index) => {
        const isSelf = entry.id === lastSelfReviewId
        const name = isSelf
          ? '你'
          : peerNicknames[(hashText(`${entry.id}-${index}`) + index) % peerNicknames.length]
        const likes = isSelf ? 0 : 3 + (hashText(`${entry.id}-${entry.text}`) % 19)
        const style = makeAvatarTone(`${entry.id}-${name}`)
        return {
          id: entry.id,
          nickname: name,
          createdAt: entry.createdAt,
          tags: entry.tags,
          text: entry.text,
          likeCount: likes,
          avatarTone: style.avatarTone,
          avatarInk: style.avatarInk,
        }
      })
  }, [lastSelfReviewId, restaurant, reviewEntries])

  const allComments = useMemo(
    () =>
      [...seedComments, ...userComments].sort((a, b) => {
        if (b.likeCount !== a.likeCount) {
          return b.likeCount - a.likeCount
        }
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      }),
    [seedComments, userComments],
  )

  const commentCount = allComments.length
  const visibleComments = commentsExpanded ? allComments : allComments.slice(0, 3)

  const collected = useMemo(() => {
    if (!restaurant) {
      return false
    }
    return favoriteEntries.some((entry) => entry.placeId === restaurant.id)
  }, [favoriteEntries, restaurant])

  const likeCount = baseLikeCount + (liked ? 1 : 0)
  const collectCount = baseCollectCount + (collected ? 1 : 0)

  useEffect(() => {
    if (!restaurant) {
      return
    }

    const startedAt = Date.now()
    startAtRef.current = startedAt
    trackEvent('detail_view', { id: restaurant.id, campusId: restaurant.campusId })

    return () => {
      const seconds = Math.round((Date.now() - startedAt) / 1000)
      trackEvent('detail_dwell', { id: restaurant.id, seconds })
    }
  }, [restaurant])

  useEffect(() => {
    return () => {
      if (toastTimerRef.current !== null) {
        window.clearTimeout(toastTimerRef.current)
      }
    }
  }, [])

  if (!restaurant || !campus) {
    return (
      <section className="empty-state">
        <h1>店铺不存在</h1>
        <p>你访问的商户可能已下架或链接错误。</p>
        <Link to="/map">回地图页</Link>
      </section>
    )
  }

  const distanceKm = calcDistanceKm(campus.center, restaurant.location)
  const walkMinutes = estimateWalkMinutes(distanceKm)
  const openNow = isOpenNow(restaurant.openHours)

  const pushToast = (text: string): void => {
    setToastText(text)
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current)
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastText('')
      toastTimerRef.current = null
    }, 2000)
  }

  const handleGo = (): void => {
    trackEvent('go_this_place', {
      id: restaurant.id,
      name: restaurant.name,
      campusId: restaurant.campusId,
    })
    printEventSummary()
    window.alert('已记录“就去这家了”，祝你吃得开心。')
  }

  const handleStartNavigation = (): void => {
    openAmapNavigation(
      {
        lng: restaurant.location.lng,
        lat: restaurant.location.lat,
        name: restaurant.name,
      },
      {
        lng: campus.center.lng,
        lat: campus.center.lat,
        name: `${campus.shortName}校区`,
      },
    )
  }

  const handleAddCustomTag = (): void => {
    const normalized = customTagInput.trim()
    if (!normalized) {
      return
    }

    if (!customTags.includes(normalized)) {
      setCustomTags((prev) => [...prev, normalized])
    }
    if (!selectedTags.includes(normalized)) {
      setSelectedTags((prev) => [...prev, normalized])
    }
    setCustomTagInput('')
  }

  const handleReviewSubmit = (): void => {
    if (!reviewText.trim()) {
      setReviewTip('写两句再发吧。')
      return
    }

    const created = appendReviewEntry({
      placeId: restaurant.id,
      tags: selectedTags,
      text: reviewText.trim(),
    })

    setReviewEntries((prev) => [created, ...prev])
    setLastSelfReviewId(created.id)
    setReviewTip('已发出，感谢你帮下一位同学少踩坑。')
    setReviewText('')
  }

  const handleLike = (): void => {
    setLiked((prev) => !prev)
  }

  const handleCollect = (): void => {
    const existed = favoriteEntries.some((entry) => entry.placeId === restaurant.id)
    if (existed) {
      const next = favoriteEntries.filter((entry) => entry.placeId !== restaurant.id)
      setFavoriteEntries(next)
      saveFavoriteEntries(next)
      pushToast('已取消收藏')
      return
    }

    const next = [{ placeId: restaurant.id, savedAt: new Date().toISOString() }, ...favoriteEntries]
    setFavoriteEntries(next)
    saveFavoriteEntries(next)
    pushToast('已收藏，可在「我的」中查看')
  }

  const handleCommentFocus = (): void => {
    reviewSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    window.setTimeout(() => {
      reviewInputRef.current?.focus()
    }, 320)
  }

  const handleCopyLink = async (): Promise<void> => {
    try {
      await copyText(window.location.href)
      setSharePanelOpen(false)
      pushToast('链接已复制')
    } catch {
      setSharePanelOpen(false)
      pushToast('复制失败，请稍后重试')
    }
  }

  const allTags = [...presetTagOptions, ...customTags]
  const backToMap = location.search ? `/map${location.search}` : '/map'

  return (
    <article className="detail-page detail-page--post">
      <header className="detail-hero">
        <div className="detail-hero__top">
          <span className="detail-hero__type">{restaurant.type === 'stall' ? '小摊贩' : '正式餐厅'}</span>
          <div className="detail-share">
            <button
              aria-label="转发"
              className="detail-share__trigger"
              onClick={() => setSharePanelOpen((prev) => !prev)}
              type="button"
            >
              ⤴
            </button>
            {sharePanelOpen ? (
              <div className="detail-share__panel">
                <button onClick={handleCopyLink} type="button">
                  复制链接
                </button>
                <button disabled type="button">
                  分享到…（即将上线）
                </button>
              </div>
            ) : null}
          </div>
        </div>

        <h1>{restaurant.type === 'stall' ? '🚩' : '🍴'} {restaurant.name}</h1>
        <p>{restaurant.vibeLine}</p>
        <div className="detail-tags">
          {restaurant.cuisines.map((item) => (
            <span key={item}>{item}</span>
          ))}
          {restaurant.tags.slice(0, 3).map((item) => (
            <span key={item}>{item}</span>
          ))}
        </div>
      </header>

      <section className="detail-story">
        <section className="detail-story__block">
          <h2>同学怎么说</h2>
          <p className="detail-story__quote">{restaurant.trustSignals.aiSummary}</p>
          <p className="detail-story__meta">大家都提到：{restaurant.trustSignals.keywords.join('、')}</p>
          <p className="detail-story__meta">本月回头吃：{restaurant.trustSignals.revisitRate30d}%</p>
        </section>

        <section className="detail-story__block">
          <h2>怎么去</h2>
          <p>
            离你大约 {formatDistance(distanceKm)}，步行 {walkMinutes} 分钟左右。
          </p>
          <p>{openNow ? '现在营业中，可以直接冲。' : '现在没开门，建议换个时段再来。'}</p>
          <p>营业时间：{formatBusinessHours(restaurant.openHours)}</p>
          <p>
            位置：
            {restaurant.type === 'stall'
              ? `${restaurant.address}（以现场出摊为准）`
              : `${restaurant.address}（${campus.name}）`}
          </p>
        </section>

        <section className="detail-story__block">
          <h2>吃什么好</h2>
          <div className="dish-grid">
            {restaurant.signatureDishes.map((dish) => (
              <span key={dish}>{dish}</span>
            ))}
          </div>
          <p className="detail-tip">
            建议先点：{restaurant.signatureDishes.slice(0, 2).join(' + ')}，人均大概 ¥{restaurant.avgPrice}。
          </p>
        </section>
      </section>

      <div className="detail-social">
        <button className={liked ? 'detail-social__btn detail-social__btn--active' : 'detail-social__btn'} onClick={handleLike} type="button">
          <span aria-hidden="true">♡</span>
          <span>{likeCount}</span>
        </button>
        <button className="detail-social__btn" onClick={handleCommentFocus} type="button">
          <span aria-hidden="true">💬</span>
          <span>{commentCount}</span>
        </button>
        <button
          className={collected ? 'detail-social__btn detail-social__btn--active' : 'detail-social__btn'}
          onClick={handleCollect}
          type="button"
        >
          <span aria-hidden="true" className="detail-social__star">{collected ? '★' : '☆'}</span>
          <span>{collectCount}</span>
        </button>
      </div>

      <footer className="detail-actions">
        <button onClick={handleGo} type="button">
          就去这家了
        </button>
        <button onClick={handleStartNavigation} type="button">
          立即导航
        </button>
        <Link to={backToMap}>再看看别家</Link>
      </footer>

      <section className="detail-card detail-card--note" ref={reviewSectionRef}>
        <h2>吃完了？说两句</h2>
        <div className="detail-note__tags">
          <p>给它打几个标签</p>
          <div className="detail-tag-cloud">
            {allTags.map((tag) => (
              <button
                className={selectedTags.includes(tag) ? 'detail-tag-pill detail-tag-pill--active' : 'detail-tag-pill'}
                key={tag}
                onClick={() => setSelectedTags((prev) => toggleTag(prev, tag))}
                type="button"
              >
                {tag}
              </button>
            ))}
            <button className="detail-tag-pill detail-tag-pill--plus" onClick={() => setShowCustomInput((prev) => !prev)} type="button">
              + 自定义
            </button>
          </div>
          {showCustomInput ? (
            <div className="detail-tag-add">
              <input
                className="note-field"
                onChange={(event) => setCustomTagInput(event.target.value)}
                placeholder="输入你的 Tag"
                value={customTagInput}
              />
              <button onClick={handleAddCustomTag} type="button">
                添加
              </button>
            </div>
          ) : null}
        </div>

        <label className="scene-form__block" htmlFor="review-text">
          <span>文字评价</span>
          <textarea
            className="note-field note-field--textarea"
            id="review-text"
            maxLength={300}
            onChange={(event) => setReviewText(event.target.value)}
            placeholder="下一个不知道吃什么的同学，正在等你的分享"
            ref={reviewInputRef}
            value={reviewText}
          />
        </label>
        <div className="detail-actions">
          <button onClick={handleReviewSubmit} type="button">
            发出去
          </button>
        </div>
        {reviewTip ? <p className="detail-tip">{reviewTip}</p> : null}
      </section>

      <section className="detail-card detail-card--comments">
        <h2>同学评论区</h2>
        <div className="detail-comments">
          {visibleComments.map((comment) => (
            <article className="detail-comment" key={comment.id}>
              <div className="detail-comment__avatar" style={{ background: comment.avatarTone, color: comment.avatarInk }}>
                {comment.nickname.slice(0, 1)}
              </div>
              <div className="detail-comment__body">
                <div className="detail-comment__meta">
                  <strong>{comment.nickname}</strong>
                  <span>{formatCommentTime(comment.createdAt)}</span>
                </div>
                <div className="detail-comment__tags">
                  {comment.tags.map((tag) => (
                    <em key={`${comment.id}-${tag}`}>{tag}</em>
                  ))}
                </div>
                <p>{comment.text}</p>
              </div>
              <span className="detail-comment__likes">♥ {comment.likeCount}</span>
            </article>
          ))}
        </div>
        {allComments.length > 3 ? (
          <button className="detail-comments__toggle" onClick={() => setCommentsExpanded((prev) => !prev)} type="button">
            {commentsExpanded ? '收起' : `查看全部 ${allComments.length} 条评论`}
          </button>
        ) : null}
      </section>

      {toastText ? <div className="detail-toast">{toastText}</div> : null}
    </article>
  )
}

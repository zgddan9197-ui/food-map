import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { campusMap, campuses, defaultCampusId } from '../data/campuses'
import { restaurants } from '../data/restaurants'
import { getTrackedEvents } from '../lib/analytics'
import { calcDistanceKm, formatDistance } from '../lib/geo'
import {
  getFavoriteEntries,
  getMessageNotifications,
  getReviewEntries,
  getTastePreference,
  saveMessageNotifications,
  saveTastePreference,
  type MessageNotification,
} from '../lib/me'

const tabooOptions = ['不吃辣', '不吃香菜', '素食', '不吃葱蒜', '不吃海鲜']
const tasteOptions = ['重口', '清淡', '甜食', '咸香', '酸辣', '汤面', '烧烤']

const formatTime = (value: string): string =>
  new Date(value).toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })

const interactionLabel = (type: MessageNotification['interaction']): string =>
  type === 'like' ? '点赞了你' : '评论了你'

const toggleTag = (source: string[], target: string): string[] =>
  source.includes(target) ? source.filter((item) => item !== target) : [...source, target]

export default function MyPage() {
  const [notifications, setNotifications] = useState(getMessageNotifications)
  const [preference, setPreference] = useState(() => getTastePreference(defaultCampusId))
  const [savedTip, setSavedTip] = useState('')
  const [viewedExpanded, setViewedExpanded] = useState(false)
  const canSavePreference = preference.tabooTags.length > 0 || preference.tasteTags.length > 0

  const favorites = useMemo(() => getFavoriteEntries(), [])
  const reviews = useMemo(() => getReviewEntries(), [])

  const favoriteCards = useMemo(
    () =>
      favorites
        .map((entry) => restaurants.find((item) => item.id === entry.placeId))
        .filter((item): item is (typeof restaurants)[number] => Boolean(item))
        .map((item) => {
          const campus = campusMap[item.campusId]
          const distance = formatDistance(calcDistanceKm(campus.center, item.location))
          return {
            id: item.id,
            name: item.name,
            distance,
            reason: item.trustSignals.aiSummary,
          }
        }),
    [favorites],
  )

  const reviewedList = useMemo(
    () =>
      reviews
        .map((entry) => {
          const place = restaurants.find((item) => item.id === entry.placeId)
          if (!place) {
            return null
          }
          return {
            ...entry,
            placeName: place.name,
          }
        })
        .filter((item): item is NonNullable<typeof item> => Boolean(item))
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [reviews],
  )

  const viewedList = useMemo(
    () => {
      const sortedEvents = getTrackedEvents()
        .filter((event) => event.name === 'detail_view')
        .sort((a, b) => new Date(b.ts).getTime() - new Date(a.ts).getTime())

      const latestByPlace = new Map<
        string,
        {
          placeId: string
          placeName: string
          placeType: 'restaurant' | 'stall'
          viewedAt: string
        }
      >()

      for (const event of sortedEvents) {
        const placeId = String(event.payload.id ?? '')
        if (!placeId || latestByPlace.has(placeId)) {
          continue
        }
        const place = restaurants.find((item) => item.id === placeId)
        if (!place) {
          continue
        }
        latestByPlace.set(placeId, {
          placeId,
          placeName: place.name,
          placeType: place.type,
          viewedAt: event.ts,
        })
      }

      return Array.from(latestByPlace.values())
    },
    [],
  )
  const visibleViewedList = viewedExpanded ? viewedList : viewedList.slice(0, 3)

  const unreadCount = notifications.filter((item) => item.unread).length

  const markAllRead = (): void => {
    const next = notifications.map((item) => ({ ...item, unread: false }))
    setNotifications(next)
    saveMessageNotifications(next)
  }

  const savePreferences = (): void => {
    if (!canSavePreference) {
      return
    }

    const saved = saveTastePreference({
      campusId: preference.campusId,
      tabooTags: preference.tabooTags,
      tasteTags: preference.tasteTags,
    })
    setPreference(saved)
    setSavedTip('已保存，下次推荐会自动带上这些偏好。')
  }

  return (
    <section className="my-page">
      <header className="my-page__hero">
        <h1>我的</h1>
        <p>你的提醒、收藏、记录和偏好都在这里。</p>
      </header>

      <section className="my-module">
        <div className="my-module__head">
          <h2>消息提醒</h2>
          {unreadCount > 0 ? (
            <button className="my-link-btn" onClick={markAllRead} type="button">
              全部已读
            </button>
          ) : null}
        </div>
        <div className="my-list">
          {notifications.map((item) => (
            <article className="my-notif" key={item.id}>
              <div className="my-notif__line">
                <strong>{item.actorName}</strong>
                <span>{interactionLabel(item.interaction)}</span>
                <em>{item.placeName}</em>
              </div>
              <p>{formatTime(item.time)}</p>
              {item.unread ? <span className="my-notif__dot" aria-label="未读" /> : null}
            </article>
          ))}
        </div>
      </section>

      <section className="my-module">
        <h2>我的收藏</h2>
        {favoriteCards.length === 0 ? (
          <p className="my-empty">还没有收藏，去逛吃地图加几家吧。</p>
        ) : (
          <div className="my-favorites-row">
            {favoriteCards.map((item) => (
              <Link className="my-favorite-card" key={item.id} to={`/detail/${item.id}`}>
                <h3>{item.name}</h3>
                <p>{item.distance}</p>
                <p>{item.reason}</p>
              </Link>
            ))}
          </div>
        )}
      </section>

      <section className="my-module">
        <h2>我评价过的</h2>
        {reviewedList.length === 0 ? (
          <p className="my-empty">你还没留下评价，吃完记得来写两句。</p>
        ) : (
          <div className="my-list">
            {reviewedList.map((item) => (
              <Link className="my-record" key={item.id} to={`/detail/${item.placeId}`}>
                <div className="my-record__title">
                  <strong>{item.placeName}</strong>
                  <span>{formatTime(item.createdAt)}</span>
                </div>
                <p>{item.tags.join('、')}</p>
                <p>{item.text}</p>
              </Link>
            ))}
          </div>
        )}
      </section>

      <section className="my-module">
        <h2>我看过的</h2>
        {viewedList.length === 0 ? (
          <p className="my-empty">还没有浏览记录，去地图看看吧。</p>
        ) : (
          <>
            <div className="my-list">
              {visibleViewedList.map((item) => (
                <Link className="my-viewed-card" key={item.placeId} to={`/detail/${item.placeId}`}>
                  <div className="my-viewed-card__head">
                    <strong>{item.placeName}</strong>
                    <span>{formatTime(item.viewedAt)}</span>
                  </div>
                  <p>{item.placeType === 'stall' ? '摊位' : '正式餐厅'}</p>
                </Link>
              ))}
            </div>
            {viewedList.length > 3 ? (
              <button className="my-link-btn my-link-btn--expand" onClick={() => setViewedExpanded((prev) => !prev)} type="button">
                {viewedExpanded ? '收起' : '展开查看全部'}
              </button>
            ) : null}
          </>
        )}
      </section>

      <section className="my-module my-module--card">
        <div className="my-pref-head">
          <h2>口味偏好设置</h2>
          <span className="my-pref-head__badge">AI 调优中</span>
        </div>
        <div className="my-preference">
          <label>
            常用校区
            <select
              onChange={(event) => setPreference((prev) => ({ ...prev, campusId: event.target.value }))}
              value={preference.campusId}
            >
              {campuses.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>
          <div>
            <p>忌口</p>
            <div className="my-tag-grid">
              {tabooOptions.map((item) => (
                <button
                  className={preference.tabooTags.includes(item) ? 'my-tag my-tag--active' : 'my-tag'}
                  key={item}
                  onClick={() =>
                    setPreference((prev) => ({ ...prev, tabooTags: toggleTag(prev.tabooTags, item) }))
                  }
                  type="button"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p>口味偏好</p>
            <div className="my-tag-grid">
              {tasteOptions.map((item) => (
                <button
                  className={preference.tasteTags.includes(item) ? 'my-tag my-tag--active' : 'my-tag'}
                  key={item}
                  onClick={() =>
                    setPreference((prev) => ({ ...prev, tasteTags: toggleTag(prev.tasteTags, item) }))
                  }
                  type="button"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
          <div className="my-preference__actions">
            <button disabled={!canSavePreference} onClick={savePreferences} type="button">
              保存偏好
            </button>
            {savedTip ? <p>{savedTip}</p> : null}
          </div>
        </div>
      </section>
    </section>
  )
}

import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { parseSceneParams } from '../api/service'
import SegmentedPicker from '../components/SegmentedPicker'
import { campuses, defaultCampusId } from '../data/campuses'
import { trackEvent } from '../lib/analytics'
import { buildPreferencePrompt, getTastePreference } from '../lib/me'
import { toSearchParams } from '../lib/scene'
import type { MealTime, PeopleCount, Urgency } from '../types/domain'

interface SpeechRecognitionAlternativeLike {
  transcript: string
}

interface SpeechRecognitionResultLike {
  isFinal: boolean
  [index: number]: SpeechRecognitionAlternativeLike
}

interface SpeechRecognitionEventLike {
  resultIndex: number
  results: SpeechRecognitionResultLike[]
}

interface SpeechRecognitionLike {
  lang: string
  continuous: boolean
  interimResults: boolean
  onresult: ((event: SpeechRecognitionEventLike) => void) | null
  onerror: ((event: { error: string }) => void) | null
  onend: (() => void) | null
  start: () => void
  stop: () => void
}

interface SpeechRecognitionConstructor {
  new (): SpeechRecognitionLike
}

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor
    webkitSpeechRecognition?: SpeechRecognitionConstructor
  }
}

const peopleOptions: Array<{ label: string; value: PeopleCount }> = [
  { label: '一个人', value: 'solo' },
  { label: '2-3 人', value: 'smallGroup' },
  { label: '4 人以上', value: 'group' },
]

const mealTimeOptions: Array<{ label: string; value: MealTime }> = [
  { label: '早餐', value: 'breakfast' },
  { label: '午餐', value: 'lunch' },
  { label: '晚餐', value: 'dinner' },
  { label: '宵夜', value: 'lateNight' },
]

const urgencyOptions: Array<{ label: string; value: Urgency }> = [
  { label: '很赶', value: 'rush' },
  { label: '正常', value: 'normal' },
  { label: '慢慢吃', value: 'relax' },
]

const inferMealTime = (): MealTime => {
  const hour = new Date().getHours()
  if (hour < 10) {
    return 'breakfast'
  }
  if (hour < 15) {
    return 'lunch'
  }
  if (hour < 22) {
    return 'dinner'
  }
  return 'lateNight'
}

export default function HomePage() {
  const navigate = useNavigate()
  const defaultMeal = useMemo(() => inferMealTime(), [])
  const savedPreference = useMemo(() => getTastePreference(defaultCampusId), [])
  const thinkingTimerRef = useRef<number | null>(null)
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null)

  const [campusId, setCampusId] = useState(savedPreference.campusId || defaultCampusId)
  const [people, setPeople] = useState<PeopleCount>('solo')
  const [mealTime, setMealTime] = useState<MealTime>(defaultMeal)
  const [urgency, setUrgency] = useState<Urgency>('normal')
  const [freeText, setFreeText] = useState('')
  const [isThinking, setIsThinking] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [speechTip, setSpeechTip] = useState('')
  const speechSupported = useMemo(
    () => typeof window !== 'undefined' && Boolean(window.SpeechRecognition ?? window.webkitSpeechRecognition),
    [],
  )

  useEffect(() => {
    return () => {
      if (thinkingTimerRef.current !== null) {
        window.clearTimeout(thinkingTimerRef.current)
      }
      recognitionRef.current?.stop()
      recognitionRef.current = null
    }
  }, [])

  useEffect(() => {
    const Recognition = window.SpeechRecognition ?? window.webkitSpeechRecognition
    if (!Recognition) {
      return
    }

    const recognition = new Recognition()
    recognition.lang = 'zh-CN'
    recognition.continuous = false
    recognition.interimResults = false

    recognition.onresult = (event) => {
      let transcript = ''
      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        const result = event.results[index]
        if (result?.isFinal) {
          transcript += result[0]?.transcript?.trim() ?? ''
        }
      }

      if (!transcript) {
        return
      }

      setFreeText((previous) => {
        const merged = previous.trim() ? `${previous.trim()} ${transcript}` : transcript
        return merged.slice(0, 120)
      })
    }

    recognition.onerror = (event) => {
      setIsListening(false)
      setSpeechTip(event.error === 'not-allowed' ? '请先允许麦克风权限。' : '语音识别失败，请重试。')
    }

    recognition.onend = () => {
      setIsListening(false)
    }

    recognitionRef.current = recognition

    return () => {
      recognition.stop()
      recognitionRef.current = null
    }
  }, [])

  const onSubmit = async (): Promise<void> => {
    if (isThinking) {
      return
    }

    setIsThinking(true)

    const preference = getTastePreference(campusId)
    const preferencePrompt = buildPreferencePrompt(preference)
    const mergedFreeText = [freeText.trim(), preferencePrompt].filter((item) => item.length > 0).join('；')

    let parsed = {
      cuisine: '',
      budget: '',
      distance: '',
    }

    if (mergedFreeText.trim()) {
      try {
        const parsedResponse = await parseSceneParams(mergedFreeText.trim())
        parsed = {
          cuisine: parsedResponse.params.cuisine?.trim() ?? '',
          budget: parsedResponse.params.budget?.trim() ?? '',
          distance: parsedResponse.params.distance?.trim() ?? '',
        }
      } catch {
        parsed = {
          cuisine: '',
          budget: '',
          distance: '',
        }
      }
    }

    const state = {
      campusId,
      people,
      mealTime,
      urgency,
      freeText: mergedFreeText,
      cuisine: parsed.cuisine,
      budget: parsed.budget,
      distance: parsed.distance,
      view: 'map' as const,
    }

    trackEvent('scene_submit', state)
    thinkingTimerRef.current = window.setTimeout(() => {
      navigate(`/map?${toSearchParams(state).toString()}`)
    }, 1000)
  }

  const toggleVoiceInput = (): void => {
    if (!speechSupported || !recognitionRef.current || isThinking) {
      return
    }

    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
      return
    }

    try {
      setSpeechTip('')
      recognitionRef.current.start()
      setIsListening(true)
    } catch {
      setSpeechTip('麦克风初始化中，请稍后重试。')
      setIsListening(false)
    }
  }

  return (
    <div className="home-page">
      <section className="hero-banner">
        <p className="hero-banner__badge">食刻 · 校园版</p>
        <h1>此刻想吃，食刻知道</h1>
        <p>现在想吃什么？</p>
      </section>

      <section className="scene-form">
        <SegmentedPicker onChange={setCampusId} options={campuses.map((item) => ({ label: item.shortName, value: item.id }))} title="你在哪" value={campusId} />
        <SegmentedPicker onChange={setPeople} options={peopleOptions} title="几个人吃" value={people} />
        <SegmentedPicker
          onChange={setMealTime}
          options={mealTimeOptions}
          title="什么时候吃"
          value={mealTime}
        />
        <SegmentedPicker
          onChange={setUrgency}
          options={urgencyOptions}
          title="时间紧不紧"
          value={urgency}
        />

        <label className="scene-form__block" htmlFor="free-text">
          <div className="scene-form__textarea-header">
            <span>说一句你现在想吃什么</span>
            <button
              aria-label="语音输入"
              className={isListening ? 'voice-trigger voice-trigger--active' : 'voice-trigger'}
              onClick={toggleVoiceInput}
              type="button"
            >
              🎤 {isListening ? '在听...' : '说一句'}
            </button>
          </div>
          <textarea
            id="free-text"
            maxLength={120}
            onChange={(event) => setFreeText(event.target.value)}
            placeholder="比如：想吃热乎的，步行 10 分钟内，30 块左右"
            value={freeText}
          />
          {!speechSupported ? <p className="scene-form__helper">当前浏览器不支持语音识别。</p> : null}
          {speechTip ? <p className="scene-form__helper">{speechTip}</p> : null}
        </label>

        <div className="scene-form__actions">
          <button onClick={() => void onSubmit()} type="button">
            帮我找
          </button>
          <p>点一下，马上给你 5 家可去的。</p>
        </div>
      </section>

      {isThinking ? (
        <div className="ai-thinking-mask" role="status" aria-live="polite">
          <div className="ai-thinking-card">
            <p>正在为您搜罗周边美味...</p>
            <div className="ai-thinking-dots">
              <span />
              <span />
              <span />
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}

import { apiGet, apiPost, adminGet, adminPost, ensureAnonymousSession } from './client'
import type {
  ApiCommunityList,
  ApiIntentHintsResponse,
  ApiModerationItem,
  ApiNotification,
  ApiPlaceDetail,
  ApiRecommendationsResponse,
  ApiSceneParseResponse,
  ApiSupplementPlacesResponse,
} from './types'
import type { SceneQueryState } from '../lib/scene'

export interface RecommendationRequest extends SceneQueryState {
  openNowOnly?: boolean
  maxWalkMinutes?: number
}

export const initAnonymousSession = async (): Promise<void> => {
  await ensureAnonymousSession()
}

export const createRecommendations = async (
  payload: RecommendationRequest,
): Promise<ApiRecommendationsResponse> =>
  apiPost<ApiRecommendationsResponse>('/api/v1/recommendations', {
    campusId: payload.campusId,
    people: payload.people,
    mealTime: payload.mealTime,
    urgency: payload.urgency,
    freeText: payload.freeText,
    openNowOnly: payload.openNowOnly ?? false,
    maxWalkMinutes: payload.maxWalkMinutes ?? 28,
  })

export const extractIntentHints = async (text: string): Promise<ApiIntentHintsResponse> =>
  apiPost<ApiIntentHintsResponse>('/api/v1/ai/intent', { text })

export const parseSceneParams = async (text: string): Promise<ApiSceneParseResponse> =>
  apiPost<ApiSceneParseResponse>('/api/v1/ai/scene-parse', { text })

export const requestSupplementPlaces = async (
  cuisine: string,
  maxItems = 2,
): Promise<ApiSupplementPlacesResponse> =>
  apiPost<ApiSupplementPlacesResponse>('/api/v1/ai/supplement-places', {
    cuisine,
    maxItems,
  })

export const refreshRecommendations = async (
  sceneId: string,
  payload: {
    previousIds: string[]
    openNowOnly?: boolean
    maxWalkMinutes?: number
    interestBoost?: Record<string, number>
  },
): Promise<ApiRecommendationsResponse & { policy: { requiredNewCount: number; actualNewCount: number } }> =>
  apiPost(`/api/v1/recommendations/${sceneId}/refresh`, {
    previousIds: payload.previousIds,
    openNowOnly: payload.openNowOnly ?? false,
    maxWalkMinutes: payload.maxWalkMinutes ?? 28,
    interestBoost: payload.interestBoost ?? {},
  })

export const getPlaceDetail = async (id: string): Promise<ApiPlaceDetail> =>
  apiGet<ApiPlaceDetail>(`/api/v1/restaurants/${id}`)

export const goThisPlace = async (sceneId: string, placeId: string) =>
  apiPost<{ decisionId: string; notificationDueAt: string }>('/api/v1/decisions/go', {
    sceneId,
    placeId,
  })

export const submitReview = async (payload: {
  placeId: string
  tags: string[]
  text: string
  images?: string[]
}) =>
  apiPost<{ reviewId: string; status: 'pending' | 'approved' | 'rejected'; qualityWeight: number }>(
    '/api/v1/reviews',
    payload,
  )

export const listCommunityPosts = async (placeId?: string): Promise<ApiCommunityList> => {
  if (placeId) {
    return apiGet<ApiCommunityList>(`/api/v1/community/posts?placeId=${encodeURIComponent(placeId)}`)
  }
  return apiGet<ApiCommunityList>('/api/v1/community/posts')
}

export const createCommunityPost = async (payload: {
  author: string
  title: string
  body: string
  placeId?: string | null
  tags?: string[]
}) =>
  apiPost<{ postId: string; status: 'pending' | 'approved' | 'rejected' }>('/api/v1/community/posts', payload)

export const createCommunityComment = async (postId: string, content: string) =>
  apiPost<{ commentId: string; status: 'pending' | 'approved' | 'rejected' }>(
    `/api/v1/community/posts/${postId}/comments`,
    { content },
  )

export const submitPlace = async (payload: {
  name: string
  type: 'restaurant' | 'stall'
  campusId: string
  addressHint: string
  note: string
}) =>
  apiPost<{ submissionId: string; status: 'pending' | 'approved' | 'rejected' }>(
    '/api/v1/submissions/place',
    payload,
  )

export const listNotifications = async (): Promise<{ notifications: ApiNotification[] }> =>
  apiGet('/api/v1/notifications/in-app')

export const ackNotification = async (id: string): Promise<{ ok: boolean }> =>
  apiPost(`/api/v1/notifications/${id}/ack`, {})

export const getModerationQueue = async (adminKey: string): Promise<{ items: ApiModerationItem[] }> =>
  adminGet('/api/v1/admin/moderation/queue', adminKey)

export const moderateQueueItem = async (
  adminKey: string,
  id: string,
  action: 'approve' | 'reject',
): Promise<{ item: ApiModerationItem }> =>
  adminPost(`/api/v1/admin/moderation/${id}/action`, { action }, adminKey)

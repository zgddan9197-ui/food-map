import type { PlaceType } from '../types/domain'

export interface ApiSessionResponse {
  anonymousToken: string
  deviceId: string
  createdAt: string
}

export interface ApiRecommendationPlace {
  id: string
  name: string
  type: PlaceType
  campusId: string
  location: {
    lng: number
    lat: number
  }
  cuisines: string[]
  tags: string[]
  rating: number
  avgPrice: number
  vibeLine: string
  signatureDishes: string[]
  trustSignals?: {
    keywords?: string[]
    revisitRate30d: number
    aiSummary: string
  }
}

export interface ApiRecommendationItem {
  place: ApiRecommendationPlace
  recommendation: {
    id: string
    score: number
    reason: string
    walkMinutes: number
  }
  distanceKm: number
  openNow: boolean
}

export interface ApiRecommendationsResponse {
  sceneId: string
  recommendations: ApiRecommendationItem[]
  totalCandidates: number
  route: Array<{
    order: number
    id: string
    lng: number
    lat: number
  }>
}

export interface ApiIntentHintsResponse {
  hints: string[]
  provider: 'noop' | 'domestic-http' | 'deepseek'
  fallback: boolean
}

export interface ApiSceneParseResponse {
  params: {
    cuisine: string
    budget: string
    distance: string
  }
  provider: 'noop' | 'domestic-http' | 'deepseek'
  fallback: boolean
}

export interface ApiSupplementPlace {
  name: string
  campusId: string
  address: string
  lng: number
  lat: number
  revisitRate30d: number
  aiSummary: string
  aiReason: string
  tags: string[]
  avgPrice: number
  rating: number
  signatureDishes: string[]
}

export interface ApiSupplementPlacesResponse {
  places: ApiSupplementPlace[]
  provider: 'noop' | 'domestic-http' | 'deepseek'
  fallback: boolean
}

export interface ApiPlaceDetail {
  place: {
    id: string
    name: string
    campusId: string
    type: PlaceType
    location: {
      lng: number
      lat: number
    }
    cuisines: string[]
    priceLevel: 1 | 2 | 3 | 4
    avgPrice: number
    rating: number
    reviewCount: number
    openHours: Array<{
      day: 0 | 1 | 2 | 3 | 4 | 5 | 6
      start: string
      end: string
    }>
    tags: string[]
    signatureDishes: string[]
    address: string
    vibeLine: string
    mealServiceSpeed: 'fast' | 'normal' | 'slow'
    trustSignals: {
      keywords: string[]
      revisitRate30d: number
      aiSummary: string
      updatedAt: string
    }
    stallHint: {
      locationHint: string
      activeHoursHint: string
    } | null
  }
}

export interface ApiCommunityComment {
  id: string
  postId: string
  content: string
  status: 'pending' | 'approved' | 'rejected'
  createdAt: string
}

export interface ApiCommunityPost {
  id: string
  author: string
  title: string
  body: string
  placeId: string | null
  placeName: string | null
  tags: string[]
  status: 'pending' | 'approved' | 'rejected'
  createdAt: string
  comments: ApiCommunityComment[]
}

export interface ApiCommunityList {
  posts: ApiCommunityPost[]
}

export interface ApiNotification {
  id: string
  title: string
  body: string
  dueAt: string
  acknowledged: boolean
  createdAt: string
}

export interface ApiModerationItem {
  id: string
  targetType: 'review' | 'community_post' | 'community_comment' | 'place_submission'
  targetId: string
  reason: string
  status: 'pending' | 'approved' | 'rejected'
  createdAt: string
  updatedAt: string
}

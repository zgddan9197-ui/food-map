import type { ApiSessionResponse } from './types'

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/+$/, '') ?? ''
const SESSION_STORAGE_KEY = 'shike_anon_session_v1'
const DEVICE_STORAGE_KEY = 'shike_device_id_v1'

interface StoredSession {
  anonymousToken: string
  deviceId: string
}

export class ApiError extends Error {
  status: number
  details: unknown

  constructor(message: string, status: number, details: unknown) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.details = details
  }
}

const readStoredSession = (): StoredSession | null => {
  if (typeof window === 'undefined') {
    return null
  }
  try {
    const raw = window.localStorage.getItem(SESSION_STORAGE_KEY)
    if (!raw) {
      return null
    }
    const parsed = JSON.parse(raw) as StoredSession
    if (!parsed?.anonymousToken || !parsed?.deviceId) {
      return null
    }
    return parsed
  } catch {
    return null
  }
}

const writeStoredSession = (session: StoredSession): void => {
  if (typeof window === 'undefined') {
    return
  }
  window.localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session))
}

const getOrCreateDeviceId = (): string => {
  if (typeof window === 'undefined') {
    return 'server-device'
  }
  const existing = window.localStorage.getItem(DEVICE_STORAGE_KEY)
  if (existing) {
    return existing
  }
  const created = `dev_${crypto.randomUUID()}`
  window.localStorage.setItem(DEVICE_STORAGE_KEY, created)
  return created
}

const requestRaw = async <T>(
  path: string,
  init: RequestInit = {},
  token?: string,
): Promise<T> => {
  const headers = new Headers(init.headers ?? {})
  headers.set('content-type', 'application/json')
  if (token) {
    headers.set('authorization', `Bearer ${token}`)
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers,
  })

  let payload: unknown = null
  try {
    payload = await response.json()
  } catch {
    payload = null
  }

  if (!response.ok) {
    throw new ApiError('API 请求失败', response.status, payload)
  }
  return payload as T
}

let sessionPromise: Promise<StoredSession> | null = null

export const ensureAnonymousSession = async (): Promise<StoredSession> => {
  const existing = readStoredSession()
  if (existing) {
    return existing
  }

  if (sessionPromise) {
    return sessionPromise
  }

  sessionPromise = (async () => {
    const deviceId = getOrCreateDeviceId()
    const data = await requestRaw<ApiSessionResponse>('/api/v1/anon/session', {
      method: 'POST',
      body: JSON.stringify({ deviceId }),
    })
    const next = { anonymousToken: data.anonymousToken, deviceId: data.deviceId }
    writeStoredSession(next)
    return next
  })()

  try {
    return await sessionPromise
  } finally {
    sessionPromise = null
  }
}

export const apiGet = async <T>(path: string): Promise<T> => {
  const session = await ensureAnonymousSession()
  return requestRaw<T>(path, { method: 'GET' }, session.anonymousToken)
}

export const apiPost = async <T>(path: string, body: unknown): Promise<T> => {
  const session = await ensureAnonymousSession()
  try {
    return await requestRaw<T>(
      path,
      {
        method: 'POST',
        body: JSON.stringify(body),
      },
      session.anonymousToken,
    )
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) {
      window.localStorage.removeItem(SESSION_STORAGE_KEY)
      const renewed = await ensureAnonymousSession()
      return requestRaw<T>(
        path,
        {
          method: 'POST',
          body: JSON.stringify(body),
        },
        renewed.anonymousToken,
      )
    }
    throw error
  }
}

export const adminGet = async <T>(path: string, adminKey: string): Promise<T> => {
  const headers = new Headers()
  headers.set('x-admin-key', adminKey)
  const response = await fetch(`${API_BASE_URL}${path}`, { headers })
  const payload = (await response.json()) as T
  if (!response.ok) {
    throw new ApiError('管理端请求失败', response.status, payload)
  }
  return payload
}

export const adminPost = async <T>(path: string, body: unknown, adminKey: string): Promise<T> => {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-admin-key': adminKey,
    },
    body: JSON.stringify(body),
  })
  const payload = (await response.json()) as T
  if (!response.ok) {
    throw new ApiError('管理端请求失败', response.status, payload)
  }
  return payload
}


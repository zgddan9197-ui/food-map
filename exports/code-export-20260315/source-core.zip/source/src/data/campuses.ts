import type { Campus } from '../types/domain'

export const campuses: Campus[] = [
  {
    id: 'wuhan-university',
    name: '武汉大学',
    shortName: '武大',
    center: { lng: 114.3658, lat: 30.5389 },
    radiusKm: 3.2,
  },
  {
    id: 'ccnu',
    name: '华中师范大学',
    shortName: '华师',
    center: { lng: 114.3602, lat: 30.5306 },
    radiusKm: 2.8,
  },
  {
    id: 'wut',
    name: '武汉理工大学',
    shortName: '武理',
    center: { lng: 114.3516, lat: 30.5188 },
    radiusKm: 3,
  },
  {
    id: 'cug',
    name: '中国地质大学（武汉）',
    shortName: '地大',
    center: { lng: 114.4129, lat: 30.5221 },
    radiusKm: 3.5,
  },
  {
    id: 'whsu',
    name: '武汉体育学院',
    shortName: '武体',
    center: { lng: 114.3754, lat: 30.5254 },
    radiusKm: 2.6,
  },
]

export const defaultCampusId = campuses[0].id

export const campusMap = campuses.reduce<Record<string, Campus>>((acc, item) => {
  acc[item.id] = item
  return acc
}, {})

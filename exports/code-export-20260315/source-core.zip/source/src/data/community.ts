export interface CommunityMoment {
  id: string
  author: string
  restaurantId: string
  restaurantName: string
  content: string
  image: string
  createdAt: string
}

export const communityMoments: CommunityMoment[] = [
  {
    id: 'm1',
    author: '武大信管院 王同学',
    restaurantId: 'wdu-luojia-noodle',
    restaurantName: '珞珈面馆（老字号）',
    content: '真的绝绝子，热干面拌得很香，早八前冲一碗超满足。',
    image:
      'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=80',
    createdAt: '2026-03-14',
  },
  {
    id: 'm2',
    author: '华师文院 陈同学',
    restaurantId: 'ccnu-squid-stall',
    restaurantName: '广埠屯铁板鱿鱼',
    content: '晚课后小队集合点，酱香味太上头了，排队也值。',
    image:
      'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=900&q=80',
    createdAt: '2026-03-13',
  },
  {
    id: 'm3',
    author: '武大城设院 赵同学',
    restaurantId: 'wdu-dinghao-dessert',
    restaurantName: '顶好甜品（必吃榜）',
    content: '杨枝甘露不踩雷，甜度刚好，晚上和室友去很治愈。',
    image:
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=900&q=80',
    createdAt: '2026-03-12',
  },
  {
    id: 'm4',
    author: '华师数统 何同学',
    restaurantId: 'ccnu-west-canteen',
    restaurantName: '华师西区食堂',
    content: '预算紧就来这里，分量很实在，工作日中午也很快。',
    image:
      'https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=900&q=80',
    createdAt: '2026-03-12',
  },
]


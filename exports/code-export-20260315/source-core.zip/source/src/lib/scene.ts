import type { MealTime, PeopleCount, SceneInput, Urgency, ViewMode } from '../types/domain'
import { defaultCampusId } from '../data/campuses'

export interface SceneQueryState extends SceneInput {
  campusId: string
  cuisine: string
  budget: string
  distance: string
  view: ViewMode
}

const peopleSet = new Set<PeopleCount>(['solo', 'smallGroup', 'group'])
const mealSet = new Set<MealTime>(['breakfast', 'lunch', 'dinner', 'lateNight'])
const urgencySet = new Set<Urgency>(['rush', 'normal', 'relax'])
const viewSet = new Set<ViewMode>(['map', 'feed'])

const safePick = <T extends string>(value: string | null, allowed: Set<T>, fallback: T): T => {
  if (!value) {
    return fallback
  }
  return allowed.has(value as T) ? (value as T) : fallback
}

export const defaultSceneState = (): SceneQueryState => ({
  campusId: defaultCampusId,
  people: 'solo',
  mealTime: 'dinner',
  urgency: 'normal',
  freeText: '',
  cuisine: '',
  budget: '',
  distance: '',
  view: 'map',
})

export const parseSceneQuery = (search: URLSearchParams): SceneQueryState => {
  const defaults = defaultSceneState()

  return {
    campusId: search.get('campus') ?? defaults.campusId,
    people: safePick(search.get('people'), peopleSet, defaults.people),
    mealTime: safePick(search.get('mealTime'), mealSet, defaults.mealTime),
    urgency: safePick(search.get('urgency'), urgencySet, defaults.urgency),
    freeText: search.get('query') ?? defaults.freeText,
    cuisine: search.get('cuisine') ?? defaults.cuisine,
    budget: search.get('budget') ?? defaults.budget,
    distance: search.get('distance') ?? defaults.distance,
    view: safePick(search.get('view'), viewSet, defaults.view),
  }
}

export const toSearchParams = (state: SceneQueryState): URLSearchParams => {
  const params = new URLSearchParams()
  params.set('campus', state.campusId)
  params.set('people', state.people)
  params.set('mealTime', state.mealTime)
  params.set('urgency', state.urgency)
  if (state.freeText.trim()) {
    params.set('query', state.freeText.trim())
  }
  if (state.cuisine.trim()) {
    params.set('cuisine', state.cuisine.trim())
  }
  if (state.budget.trim()) {
    params.set('budget', state.budget.trim())
  }
  if (state.distance.trim()) {
    params.set('distance', state.distance.trim())
  }
  params.set('view', state.view)
  return params
}

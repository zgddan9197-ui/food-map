import { defaultCampusId } from '../data/campuses'

export type MessageInteraction = 'like' | 'comment'

export interface MessageNotification {
  id: string
  actorName: string
  interaction: MessageInteraction
  placeId: string
  placeName: string
  time: string
  unread: boolean
}

export interface FavoriteEntry {
  placeId: string
  savedAt: string
}

export interface ReviewEntry {
  id: string
  placeId: string
  tags: string[]
  text: string
  createdAt: string
}

export interface TastePreference {
  campusId: string
  tabooTags: string[]
  tasteTags: string[]
  updatedAt: string
}

const KEY_NOTIFICATIONS = 'shike_me_notifications_v1'
const KEY_FAVORITES = 'shike_me_favorites_v1'
const KEY_REVIEWS = 'shike_me_reviews_v1'
const KEY_PREFERENCES = 'shike_me_preferences_v1'

const seedNotifications: MessageNotification[] = [
  {
    id: 'notif-1',
    actorName: '小林',
    interaction: 'like',
    placeId: 'wdu-luojia-noodle',
    placeName: '珞珈面馆（老字号）',
    time: new Date(Date.now() - 1.5 * 60 * 60 * 1000).toISOString(),
    unread: true,
  },
  {
    id: 'notif-2',
    actorName: '阿沫',
    interaction: 'comment',
    placeId: 'ccnu-west-canteen',
    placeName: '华师西区食堂',
    time: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    unread: true,
  },
  {
    id: 'notif-3',
    actorName: '浩子',
    interaction: 'like',
    placeId: 'wdu-dinghao-dessert',
    placeName: '顶好甜品（必吃榜）',
    time: new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString(),
    unread: false,
  },
]

const seedFavorites: FavoriteEntry[] = [
  { placeId: 'wdu-luojia-noodle', savedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString() },
  { placeId: 'wdu-dinghao-dessert', savedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString() },
  { placeId: 'ccnu-west-canteen', savedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString() },
]

const safeRead = <T>(key: string): T | null => {
  if (typeof window === 'undefined') {
    return null
  }
  try {
    const raw = window.localStorage.getItem(key)
    if (!raw) {
      return null
    }
    return JSON.parse(raw) as T
  } catch {
    return null
  }
}

const safeWrite = <T>(key: string, value: T): void => {
  if (typeof window === 'undefined') {
    return
  }
  window.localStorage.setItem(key, JSON.stringify(value))
}

export const getMessageNotifications = (): MessageNotification[] => {
  const stored = safeRead<MessageNotification[]>(KEY_NOTIFICATIONS)
  if (stored && Array.isArray(stored)) {
    return stored
  }
  safeWrite(KEY_NOTIFICATIONS, seedNotifications)
  return seedNotifications
}

export const saveMessageNotifications = (items: MessageNotification[]): void => {
  safeWrite(KEY_NOTIFICATIONS, items)
}

export const getFavoriteEntries = (): FavoriteEntry[] => {
  const stored = safeRead<FavoriteEntry[]>(KEY_FAVORITES)
  if (stored && Array.isArray(stored)) {
    return stored
  }
  safeWrite(KEY_FAVORITES, seedFavorites)
  return seedFavorites
}

export const saveFavoriteEntries = (items: FavoriteEntry[]): void => {
  safeWrite(KEY_FAVORITES, items)
}

export const getReviewEntries = (): ReviewEntry[] => {
  const stored = safeRead<ReviewEntry[]>(KEY_REVIEWS)
  if (stored && Array.isArray(stored)) {
    return stored
  }
  return []
}

export const appendReviewEntry = (entry: Omit<ReviewEntry, 'id' | 'createdAt'>): ReviewEntry => {
  const next: ReviewEntry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
    ...entry,
  }
  const current = getReviewEntries()
  saveReviewEntries([next, ...current].slice(0, 80))
  return next
}

export const saveReviewEntries = (items: ReviewEntry[]): void => {
  safeWrite(KEY_REVIEWS, items)
}

export const getTastePreference = (fallbackCampus = defaultCampusId): TastePreference => {
  const stored = safeRead<TastePreference>(KEY_PREFERENCES)
  if (stored) {
    return stored
  }
  return {
    campusId: fallbackCampus,
    tabooTags: [],
    tasteTags: [],
    updatedAt: new Date().toISOString(),
  }
}

export const saveTastePreference = (value: Omit<TastePreference, 'updatedAt'>): TastePreference => {
  const next: TastePreference = {
    ...value,
    updatedAt: new Date().toISOString(),
  }
  safeWrite(KEY_PREFERENCES, next)
  return next
}

export const buildPreferencePrompt = (pref: TastePreference): string => {
  const pieces: string[] = []
  if (pref.tabooTags.length > 0) {
    pieces.push(`忌口：${pref.tabooTags.join('、')}`)
  }
  if (pref.tasteTags.length > 0) {
    pieces.push(`口味偏好：${pref.tasteTags.join('、')}`)
  }
  return pieces.join('；')
}

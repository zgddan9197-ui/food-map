export interface NavigationPoint {
  lng: number
  lat: number
  name: string
}

export const buildAmapWebNavigationUrl = (
  to: NavigationPoint,
  from?: NavigationPoint,
): string => {
  const params = new URLSearchParams({
    to: `${to.lng},${to.lat},${to.name}`,
    mode: 'walk',
    src: 'shike',
    coordinate: 'gaode',
    callnative: '1',
  })

  if (from) {
    params.set('from', `${from.lng},${from.lat},${from.name}`)
  }

  return `https://uri.amap.com/navigation?${params.toString()}`
}

export const openAmapNavigation = (
  to: NavigationPoint,
  fallbackFrom: NavigationPoint,
): void => {
  const openNavigation = (from?: NavigationPoint): void => {
    const url = buildAmapWebNavigationUrl(to, from)
    window.open(url, '_blank', 'noopener,noreferrer')
  }

  if (typeof navigator === 'undefined' || !navigator.geolocation) {
    openNavigation(fallbackFrom)
    return
  }

  navigator.geolocation.getCurrentPosition(
    (position) => {
      openNavigation({
        lng: position.coords.longitude,
        lat: position.coords.latitude,
        name: '我的位置',
      })
    },
    () => {
      openNavigation(fallbackFrom)
    },
    {
      enableHighAccuracy: true,
      timeout: 4500,
      maximumAge: 60 * 1000,
    },
  )
}


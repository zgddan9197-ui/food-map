const STORAGE_KEY = 'shike_events_v1'

export type AnalyticsEventName =
  | 'scene_submit'
  | 'batch_refresh'
  | 'detail_view'
  | 'detail_dwell'
  | 'go_this_place'
  | 'card_open_detail'

export interface AnalyticsEvent {
  id: string
  name: AnalyticsEventName
  ts: string
  payload: Record<string, unknown>
}

const safeRead = (): AnalyticsEvent[] => {
  if (typeof window === 'undefined') {
    return []
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) {
      return []
    }
    const parsed = JSON.parse(raw) as AnalyticsEvent[]
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

const safeWrite = (events: AnalyticsEvent[]): void => {
  if (typeof window === 'undefined') {
    return
  }
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(events))
}

export const trackEvent = (name: AnalyticsEventName, payload: Record<string, unknown> = {}): void => {
  const events = safeRead()
  const event: AnalyticsEvent = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    name,
    ts: new Date().toISOString(),
    payload,
  }
  const next = [...events, event]
  safeWrite(next)

  // Keep a clear, inspectable stream during demo sessions.
  console.info('[食刻埋点]', event)
}

export const getTrackedEvents = (): AnalyticsEvent[] => safeRead()

export const printEventSummary = (): void => {
  const events = safeRead()
  const summary = events.reduce<Record<string, number>>((acc, event) => {
    acc[event.name] = (acc[event.name] ?? 0) + 1
    return acc
  }, {})
  console.table(summary)
}

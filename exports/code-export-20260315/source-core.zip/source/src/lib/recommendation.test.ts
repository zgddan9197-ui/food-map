import { describe, expect, it } from 'vitest'
import { campuses } from '../data/campuses'
import { restaurants } from '../data/restaurants'
import { buildRankedRecommendations, selectNextBatch } from './recommendation'

describe('recommendation batch policy', () => {
  it('keeps at least 40% new stores after refresh when pool is enough', () => {
    const campus = campuses[0]
    const scene = {
      people: 'smallGroup' as const,
      mealTime: 'dinner' as const,
      urgency: 'normal' as const,
      freeText: '想吃辣的，不要太贵',
    }

    const scoped = restaurants.filter((item) => item.campusId === campus.id)
    const ranked = buildRankedRecommendations(scoped, scene, campus, {})

    const firstBatch = selectNextBatch(ranked, new Set(), new Set(), 5)
    const seen = new Set(firstBatch.map((item) => item.restaurant.id))
    const secondBatch = selectNextBatch(
      ranked,
      new Set(firstBatch.map((item) => item.restaurant.id)),
      seen,
      5,
    )

    const newCount = secondBatch.filter((item) => !seen.has(item.restaurant.id)).length
    expect(newCount).toBeGreaterThanOrEqual(2)
  })
})

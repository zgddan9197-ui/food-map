declare global {
  interface Window {
    _AMapSecurityConfig?: {
      securityJsCode: string
    }
  }
}

export const amapKey = (import.meta.env.VITE_AMAP_KEY as string | undefined)?.trim()

export const setupAmapSecurityConfig = (): void => {
  if (typeof window === 'undefined') {
    return
  }

  const securityJsCode = (import.meta.env.VITE_AMAP_SECURITY_CODE as string | undefined)?.trim()
  if (!securityJsCode) {
    return
  }

  // 高德官方“安全加载”要求：在加载 JS API 前挂载该全局配置。
  window._AMapSecurityConfig = {
    securityJsCode,
  }
}


import type {
  Campus,
  RecommendationItem,
  Restaurant,
  RestaurantWithRecommendation,
  SceneInput,
} from '../types/domain'
import { calcDistanceKm, estimateWalkMinutes } from './geo'
import { extractIntentTokens, type IntentToken } from './nlp'
import { isOpenNow } from './time'

interface ScoreBreakdown {
  score: number
  reason: string
}

const intentToTerms: Record<IntentToken, string[]> = {
  spicy: ['辣', '麻辣', '川味'],
  sweet: ['甜', '糖水', '甜品'],
  warm: ['暖胃', '汤', '粥'],
  cheap: ['便宜', '性价比', '学生'],
  groupFriendly: ['聚餐', '朋友', '拼桌'],
  quick: ['出餐快', '极快出餐', '打包方便'],
  lateNight: ['夜宵', '凌晨', '晚课后'],
  light: ['轻食', '清爽', '低负担'],
  quiet: ['慢慢吃', '环境好', '安静'],
}

const containsAny = (source: string[], terms: string[]): boolean =>
  terms.some((term) => source.some((text) => text.includes(term)))

const scoreByScene = (restaurant: Restaurant, scene: SceneInput): number => {
  let score = 0

  if (scene.people === 'solo' && restaurant.tags.some((tag) => tag.includes('一人食'))) {
    score += 8
  }

  if (scene.people === 'smallGroup' && containsAny(restaurant.tags, ['朋友', '两人', '拼桌'])) {
    score += 6
  }

  if (scene.people === 'group' && containsAny(restaurant.tags, ['聚餐', '社团', '拼桌'])) {
    score += 8
  }

  if (scene.mealTime === 'breakfast' && containsAny([...restaurant.cuisines, ...restaurant.tags], ['早餐', '粥', '煎饼'])) {
    score += 7
  }

  if (scene.mealTime === 'lunch' && containsAny([...restaurant.tags], ['午餐', '轻食', '出餐快'])) {
    score += 6
  }

  if (scene.mealTime === 'dinner' && containsAny([...restaurant.tags], ['晚餐', '聚餐', '下饭'])) {
    score += 6
  }

  if (scene.mealTime === 'lateNight' && containsAny([...restaurant.tags], ['夜宵', '晚课后', '暖胃'])) {
    score += 9
  }

  if (scene.urgency === 'rush') {
    if (restaurant.mealServiceSpeed === 'fast') {
      score += 10
    }
    if (restaurant.mealServiceSpeed === 'normal') {
      score += 3
    }
  }

  if (scene.urgency === 'relax' && restaurant.mealServiceSpeed === 'slow') {
    score += 5
  }

  return score
}

const scoreByIntent = (restaurant: Restaurant, freeText: string): number => {
  const tokens = extractIntentTokens(freeText)
  if (tokens.length === 0) {
    return 0
  }

  const texts = [restaurant.name, ...restaurant.cuisines, ...restaurant.tags]
  return tokens.reduce((sum, token) => {
    return containsAny(texts, intentToTerms[token]) ? sum + 8 : sum
  }, 0)
}

const scoreByTrust = (restaurant: Restaurant): number => {
  const ratingScore = restaurant.rating * 8
  const revisitScore = restaurant.trustSignals.revisitRate30d * 0.35
  const reviewScore = Math.log10(restaurant.reviewCount + 10) * 6
  return ratingScore + revisitScore + reviewScore
}

const scoreByDistance = (
  distanceKm: number,
  scene: SceneInput,
  serviceSpeed: Restaurant['mealServiceSpeed'],
): number => {
  const basePenalty = scene.urgency === 'rush' ? 6.5 : 4.5
  const speedBonus = serviceSpeed === 'fast' ? 2 : 0
  return 25 - distanceKm * basePenalty + speedBonus
}

const scoreByInterestBoost = (restaurant: Restaurant, boost: Record<string, number>): number => {
  const allTags = [...restaurant.cuisines, ...restaurant.tags]
  return allTags.reduce((sum, tag) => sum + (boost[tag] ?? 0), 0)
}

const createReason = (
  restaurant: Restaurant,
  walkMinutes: number,
  scene: SceneInput,
  openNow: boolean,
): string => {
  const timeLabel =
    scene.mealTime === 'breakfast'
      ? '早餐'
      : scene.mealTime === 'lunch'
        ? '午餐'
        : scene.mealTime === 'dinner'
          ? '晚餐'
          : '宵夜'

  const speedLabel =
    restaurant.mealServiceSpeed === 'fast'
      ? `${timeLabel}出餐快`
      : restaurant.mealServiceSpeed === 'slow'
        ? `${timeLabel}氛围更适合慢慢吃`
        : `${timeLabel}节奏稳定`

  const openLabel = openNow ? '当前营业中' : '稍后营业'
  const trustKeyword = restaurant.trustSignals.keywords[0] ?? '口碑稳定'

  return `步行约 ${walkMinutes} 分钟，${speedLabel}，多人提到“${trustKeyword}”，${openLabel}`
}

const scoreRestaurant = (
  restaurant: Restaurant,
  scene: SceneInput,
  campus: Campus,
  interestBoost: Record<string, number>,
): ScoreBreakdown & { distanceKm: number; openNow: boolean; walkMinutes: number } => {
  const distanceKm = calcDistanceKm(campus.center, restaurant.location)
  const walkMinutes = estimateWalkMinutes(distanceKm)
  const openNow = isOpenNow(restaurant.openHours)

  let score = 0
  score += scoreByScene(restaurant, scene)
  score += scoreByIntent(restaurant, scene.freeText)
  score += scoreByTrust(restaurant)
  score += scoreByDistance(distanceKm, scene, restaurant.mealServiceSpeed)
  score += scoreByInterestBoost(restaurant, interestBoost)
  score += openNow ? 8 : -6

  const reason = createReason(restaurant, walkMinutes, scene, openNow)
  return { score, reason, distanceKm, openNow, walkMinutes }
}

export const buildRankedRecommendations = (
  restaurants: Restaurant[],
  scene: SceneInput,
  campus: Campus,
  interestBoost: Record<string, number>,
): RestaurantWithRecommendation[] => {
  const ranked = restaurants.map((restaurant) => {
    const result = scoreRestaurant(restaurant, scene, campus, interestBoost)

    const recommendation: RecommendationItem = {
      id: restaurant.id,
      score: Math.round(result.score * 100) / 100,
      reason: result.reason,
      walkMinutes: result.walkMinutes,
    }

    return {
      restaurant,
      recommendation,
      distanceKm: result.distanceKm,
      openNow: result.openNow,
    }
  })

  ranked.sort((a, b) => b.recommendation.score - a.recommendation.score)
  return ranked
}

export const selectNextBatch = (
  ranked: RestaurantWithRecommendation[],
  previousBatchIds: Set<string>,
  seenIds: Set<string>,
  size = 5,
): RestaurantWithRecommendation[] => {
  if (ranked.length <= size) {
    return ranked
  }

  const picked: RestaurantWithRecommendation[] = []
  const pickedIds = new Set<string>()

  const pickFrom = (pool: RestaurantWithRecommendation[], limit: number): void => {
    for (const item of pool) {
      if (picked.length >= limit) {
        break
      }
      if (pickedIds.has(item.restaurant.id)) {
        continue
      }
      picked.push(item)
      pickedIds.add(item.restaurant.id)
    }
  }

  const targetNewCount = Math.ceil(size * 0.4)
  const newPool = ranked.filter((item) => !seenIds.has(item.restaurant.id))
  pickFrom(newPool, targetNewCount)

  const nonPreviousPool = ranked.filter((item) => !previousBatchIds.has(item.restaurant.id))
  pickFrom(nonPreviousPool, size)

  if (picked.length < size) {
    pickFrom(ranked, size)
  }

  return picked.slice(0, size)
}

import { describe, expect, it } from 'vitest'
import { isOpenNow } from './time'

describe('isOpenNow', () => {
  const slots = [{ day: 5 as const, start: '18:00', end: '02:00' }]

  it('supports same-day open window', () => {
    const now = new Date('2026-03-13T20:00:00+08:00')
    expect(isOpenNow(slots, now, 'Asia/Shanghai')).toBe(true)
  })

  it('supports cross-midnight window', () => {
    const now = new Date('2026-03-14T01:30:00+08:00')
    expect(isOpenNow(slots, now, 'Asia/Shanghai')).toBe(true)
  })

  it('returns false out of range', () => {
    const now = new Date('2026-03-14T03:15:00+08:00')
    expect(isOpenNow(slots, now, 'Asia/Shanghai')).toBe(false)
  })
})

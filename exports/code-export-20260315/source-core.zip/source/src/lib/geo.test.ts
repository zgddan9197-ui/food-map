import { describe, expect, it } from 'vitest'
import { calcDistanceKm, estimateWalkMinutes } from './geo'

describe('geo utilities', () => {
  it('returns zero for identical points', () => {
    const point = { lng: 113.3652, lat: 23.1578 }
    expect(calcDistanceKm(point, point)).toBeCloseTo(0, 5)
  })

  it('estimates reasonable walk minutes', () => {
    const walkMinutes = estimateWalkMinutes(1)
    expect(walkMinutes).toBe(17)
  })
})

interface Option<T extends string> {
  label: string
  value: T
}

interface SegmentedPickerProps<T extends string> {
  title: string
  options: Option<T>[]
  value: T
  onChange: (value: T) => void
}

export default function SegmentedPicker<T extends string>({
  title,
  options,
  value,
  onChange,
}: SegmentedPickerProps<T>) {
  return (
    <section className="segment-card">
      <h3>{title}</h3>
      <div className="segment-card__options">
        {options.map((option) => (
          <button
            className={option.value === value ? 'chip chip--active' : 'chip'}
            key={option.value}
            onClick={() => onChange(option.value)}
            type="button"
          >
            <strong>{option.label}</strong>
          </button>
        ))}
      </div>
    </section>
  )
}

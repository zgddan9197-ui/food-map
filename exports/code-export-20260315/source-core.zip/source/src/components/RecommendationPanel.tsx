import { Link } from 'react-router-dom'
import type { ApiRecommendationItem } from '../api/types'

interface RecommendationPanelProps {
  items: ApiRecommendationItem[]
  activeId: string | null
  search: string
  onActive: (id: string) => void
  onNavigate: (item: ApiRecommendationItem) => void
  onOpenDetail: (item: ApiRecommendationItem) => void
}

export default function RecommendationPanel({
  items,
  activeId,
  search,
  onActive,
  onNavigate,
  onOpenDetail,
}: RecommendationPanelProps) {
  return (
    <section className="recommendation-panel" aria-label="推荐结果">
      {items.map((item) => {
        const isActive = item.place.id === activeId
        const revisitRate = item.place.trustSignals?.revisitRate30d
        const aiReason = item.place.trustSignals?.aiSummary || item.recommendation.reason
        return (
          <article
            className={isActive ? 'recommend-card recommend-card--active' : 'recommend-card'}
            key={item.place.id}
            onClick={() => onActive(item.place.id)}
            onMouseEnter={() => onActive(item.place.id)}
          >
            <div className="recommend-card__header">
              <strong>{item.place.name}</strong>
              <span className="recommend-card__rate">♥ {revisitRate ? `${revisitRate}%` : '--'}</span>
            </div>
            <p className="recommend-card__reason">{aiReason}</p>
            <div className="recommend-card__actions">
              <Link
                onClick={(event) => {
                  event.stopPropagation()
                  onOpenDetail(item)
                }}
                to={`/detail/${item.place.id}?${search}`}
              >
                查看详情
              </Link>
              <button
                className="recommend-card__navigate"
                onClick={(event) => {
                  event.stopPropagation()
                  onNavigate(item)
                }}
                type="button"
              >
                <span>立即导航</span>
              </button>
            </div>
          </article>
        )
      })}
    </section>
  )
}

import type { TrustSignals as TrustSignalsType } from '../types/domain'

interface TrustSignalsProps {
  signals: TrustSignalsType
}

export default function TrustSignals({ signals }: TrustSignalsProps) {
  return (
    <section className="detail-card">
      <h2>同学怎么说</h2>
      <div className="trust-grid">
        <div>
          <h3>大家都提到</h3>
          <p>{signals.keywords.length > 0 ? signals.keywords.join('、') : '暂无高频词数据'}</p>
        </div>
        <div>
          <h3>本月回头吃</h3>
          <p>{signals.revisitRate30d}%</p>
        </div>
        <div>
          <h3>一句话总结</h3>
          <p>{signals.aiSummary || '同学反馈稳定，建议先试招牌菜。'}</p>
        </div>
      </div>
    </section>
  )
}

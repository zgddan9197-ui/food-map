import { Link } from 'react-router-dom'
import type { ApiRecommendationItem } from '../api/types'

interface FeedViewProps {
  items: ApiRecommendationItem[]
  search: string
  onNavigate: (item: ApiRecommendationItem) => void
  onOpenDetail: (item: ApiRecommendationItem) => void
}

interface CuisineGradientTheme {
  keywords: string[]
  background: string
}

const cuisineGradientThemes: CuisineGradientTheme[] = [
  {
    keywords: ['汉堡', '西式', '披萨', '牛排', 'brunch', '西餐'],
    background: 'linear-gradient(135deg, #f97316, #fdba74)',
  },
  {
    keywords: ['面', '粉', '拉面', '面食', '米线', '热干面'],
    background: 'linear-gradient(135deg, #f6d365, #fceabb)',
  },
  {
    keywords: ['甜品', '奶茶', '糖水', '蛋糕', '咖啡', '甜食'],
    background: 'linear-gradient(135deg, #f9a8d4, #fbcfe8)',
  },
  {
    keywords: ['夜宵', '烧烤', '小吃', '串', '铁板', '摊位'],
    background: 'linear-gradient(135deg, #ea580c, #fb923c)',
  },
]

const fallbackGradient = 'linear-gradient(135deg, #f59e0b, #fcd34d)'

const buildCuisineLabel = (item: ApiRecommendationItem): string => {
  const primary = item.place.cuisines.slice(0, 2)
  if (primary.length > 0) {
    return primary.join(' · ')
  }
  if (item.place.tags.length > 0) {
    return item.place.tags.slice(0, 2).join(' · ')
  }
  return item.place.type === 'stall' ? '夜宵 · 小吃' : '校园美食'
}

const resolveCuisineGradient = (item: ApiRecommendationItem): string => {
  const searchable = `${item.place.name} ${item.place.cuisines.join(' ')} ${item.place.tags.join(' ')}`.toLowerCase()
  for (const theme of cuisineGradientThemes) {
    if (theme.keywords.some((keyword) => searchable.includes(keyword.toLowerCase()))) {
      return theme.background
    }
  }
  return fallbackGradient
}

export default function FeedView({ items, search, onNavigate, onOpenDetail }: FeedViewProps) {
  return (
    <section className="feed-view" aria-label="图片流推荐">
      {items.map((item) => {
        const cuisineLabel = buildCuisineLabel(item)
        const gradient = resolveCuisineGradient(item)
        const aiReason = item.place.trustSignals?.aiSummary || item.recommendation.reason
        const revisitRate = item.place.trustSignals?.revisitRate30d
        const metaLine = `人均 ¥${item.place.avgPrice} · 步行 ${item.recommendation.walkMinutes} 分钟`

        return (
          <article className="feed-card" key={item.place.id}>
            <div className="feed-card__media" style={{ background: gradient }}>
              <p className="feed-card__media-label">{cuisineLabel}</p>
            </div>
            <div className="feed-card__content">
              <h3>{item.place.name}</h3>
              <p className="feed-card__reason">{aiReason}</p>
              <p className="feed-card__meta">{metaLine}</p>
              <p className="feed-card__rate">回头率 {revisitRate ? `${revisitRate}%` : '--'}</p>
              <div className="feed-card__actions">
                <button
                  className="feed-card__action feed-card__action--nav"
                  onClick={() => onNavigate(item)}
                  type="button"
                >
                  立即导航
                </button>
                <Link
                  className="feed-card__action feed-card__action--detail"
                  onClick={() => onOpenDetail(item)}
                  to={`/detail/${item.place.id}?${search}`}
                >
                  查看详情
                </Link>
              </div>
            </div>
          </article>
        )
      })}
    </section>
  )
}

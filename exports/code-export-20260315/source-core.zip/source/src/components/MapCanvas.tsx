import AMapLoader from '@amap/amap-jsapi-loader'
import { useEffect, useRef, useState, type MutableRefObject } from 'react'
import { amapKey, setupAmapSecurityConfig } from '../lib/amap'
import type { PlaceType } from '../types/domain'

interface MapPoint {
  id: string
  name: string
  type: PlaceType
  location: {
    lng: number
    lat: number
  }
  reason: string
}

interface MapCanvasProps {
  center: {
    lng: number
    lat: number
  }
  points: MapPoint[]
  activeId: string | null
  onSelect: (id: string) => void
}

type LngLatTuple = [number, number]

interface AMapMap {
  setFitView: (overlays?: AMapOverlay[]) => void
  setCenter: (position: LngLatTuple) => void
  panTo?: (position: LngLatTuple) => void
  addControl?: (control: unknown) => void
  destroy: () => void
}

interface AMapOverlay {
  setMap: (map: AMapMap | null) => void
}

interface AMapMarker extends AMapOverlay {
  on: (event: 'click', handler: () => void) => void
}

type AMapPolyline = AMapOverlay

type AMapPixel = unknown

interface AMapWalking {
  clear?: () => void
  search: (
    from: LngLatTuple,
    to: LngLatTuple,
    callback: (status: string, result: unknown) => void,
  ) => void
}

interface AMapGeolocationResult {
  position?: {
    lng: number
    lat: number
  }
}

interface AMapGeolocation {
  getCurrentPosition: (
    callback: (status: 'complete' | 'error', result: AMapGeolocationResult) => void,
  ) => void
}

declare global {
  interface Window {
    AMap: {
      Map: new (container: HTMLDivElement, options: Record<string, unknown>) => AMapMap
      Marker: new (options: Record<string, unknown>) => AMapMarker
      Polyline: new (options: Record<string, unknown>) => AMapPolyline
      Pixel: new (x: number, y: number) => AMapPixel
      Walking?: new (options: Record<string, unknown>) => AMapWalking
      Geolocation?: new (options: Record<string, unknown>) => AMapGeolocation
    }
  }
}

type MapStatus = 'loading' | 'ready' | 'error'

const mapStyle = 'amap://styles/whitesmoke'

const extractWalkingPath = (result: unknown): LngLatTuple[] => {
  const data = result as {
    routes?: Array<{
      steps?: Array<{
        path?: Array<{ lng: number; lat: number } | [number, number]>
      }>
    }>
  }

  const steps = data.routes?.[0]?.steps ?? []
  const points: LngLatTuple[] = []

  for (const step of steps) {
    for (const node of step.path ?? []) {
      if (Array.isArray(node) && node.length >= 2) {
        points.push([Number(node[0]), Number(node[1])])
        continue
      }

      if (typeof node === 'object' && node && 'lng' in node && 'lat' in node) {
        points.push([node.lng, node.lat])
      }
    }
  }

  return points
}

const samePoint = (a: LngLatTuple, b: LngLatTuple): boolean =>
  Math.abs(a[0] - b[0]) < 0.000001 && Math.abs(a[1] - b[1]) < 0.000001

const clearOverlayCollection = (collectionRef: MutableRefObject<AMapOverlay[]>): void => {
  collectionRef.current.forEach((overlay) => overlay.setMap?.(null))
  collectionRef.current = []
}

export default function MapCanvas({ center, points, activeId, onSelect }: MapCanvasProps) {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const mapRef = useRef<AMapMap | null>(null)
  const markerOverlaysRef = useRef<AMapOverlay[]>([])
  const routeOverlaysRef = useRef<AMapOverlay[]>([])
  const routeRequestIdRef = useRef(0)
  const [origin, setOrigin] = useState<LngLatTuple | null>(null)
  const [status, setStatus] = useState<MapStatus>(amapKey ? 'loading' : 'error')

  useEffect(() => {
    if (!amapKey || !containerRef.current) {
      setStatus('error')
      return
    }

    let cancelled = false

    setupAmapSecurityConfig()

    AMapLoader.load({
      key: amapKey,
      version: '2.0',
      plugins: ['AMap.Scale', 'AMap.ToolBar', 'AMap.Walking', 'AMap.Geolocation'],
    })
      .then(() => {
        if (cancelled || !containerRef.current) {
          return
        }

        mapRef.current = new window.AMap.Map(containerRef.current, {
          zoom: 14,
          center: [center.lng, center.lat],
          mapStyle,
          viewMode: '2D',
        })

        console.log('地图加载成功')
        setStatus('ready')
      })
      .catch(() => {
        setStatus('error')
      })

    return () => {
      cancelled = true
      clearOverlayCollection(markerOverlaysRef)
      clearOverlayCollection(routeOverlaysRef)
      mapRef.current?.destroy?.()
      mapRef.current = null
    }
  }, [center.lat, center.lng])

  useEffect(() => {
    if (!mapRef.current || status !== 'ready') {
      return
    }

    const map = mapRef.current
    let cancelled = false

    // 默认使用校区中心作为起点；定位成功后自动替换为用户当前位置。
    setOrigin([center.lng, center.lat])

    const Geolocation = window.AMap.Geolocation
    if (!Geolocation) {
      return
    }

    try {
      const geolocation = new Geolocation({
        enableHighAccuracy: true,
        timeout: 5000,
        zoomToAccuracy: false,
      })
      map.addControl?.(geolocation)
      geolocation.getCurrentPosition((geoStatus, result) => {
        if (cancelled || geoStatus !== 'complete') {
          return
        }
        const position = result.position
        if (!position) {
          return
        }
        setOrigin([position.lng, position.lat])
      })
    } catch {
      // ignored: fallback origin already set to campus center
    }

    return () => {
      cancelled = true
    }
  }, [center.lat, center.lng, status])

  useEffect(() => {
    if (!mapRef.current || status !== 'ready' || !origin) {
      return
    }

    const map = mapRef.current
    const routeRequestId = routeRequestIdRef.current + 1
    routeRequestIdRef.current = routeRequestId

    clearOverlayCollection(markerOverlaysRef)
    clearOverlayCollection(routeOverlaysRef)

    const markers = points.map((point, index) => {
      const icon = point.type === 'stall' ? '🚩' : '🍴'
      const highlightClass = activeId === point.id ? 'is-active' : ''
      const marker = new window.AMap.Marker({
        position: [point.location.lng, point.location.lat],
        offset: new window.AMap.Pixel(-18, -18),
        zIndex: activeId === point.id ? 190 : 120 + index,
        title: point.name,
        content: `<button class="map-marker ${highlightClass}" type="button" aria-label="${point.name}">${icon}</button>`,
      })
      marker.on('click', () => onSelect(point.id))
      marker.setMap(map)
      markerOverlaysRef.current.push(marker)
      return marker
    })

    const originMarker = new window.AMap.Marker({
      position: origin,
      offset: new window.AMap.Pixel(-16, -16),
      zIndex: 240,
      title: '我的位置',
      content: '<span class="map-origin-marker" aria-label="我的位置">●</span>',
    })
    originMarker.setMap(map)
    routeOverlaysRef.current.push(originMarker)

    const activePoint = points.find((item) => item.id === activeId) ?? points[0]
    if (!activePoint) {
      map.setFitView([...markerOverlaysRef.current, ...routeOverlaysRef.current])
      return
    }

    const routeStops: LngLatTuple[] = [origin, [activePoint.location.lng, activePoint.location.lat]]
    const activePointIndex = points.findIndex((item) => item.id === activePoint.id)
    const activeMarker = activePointIndex >= 0 ? markers[activePointIndex] : null

    const getFocusOverlays = (): AMapOverlay[] => {
      const overlays: AMapOverlay[] = [originMarker]
      if (activeMarker) {
        overlays.push(activeMarker)
      }
      routeOverlaysRef.current.forEach((overlay) => {
        if (overlay !== originMarker) {
          overlays.push(overlay)
        }
      })
      return overlays
    }

    const drawFallbackRoute = (): void => {
      if (routeStops.length < 2 || routeRequestId !== routeRequestIdRef.current) {
        return
      }
      const fallbackPolyline = new window.AMap.Polyline({
        path: routeStops,
        strokeColor: '#FB923C',
        strokeWeight: 6,
        strokeOpacity: 0.62,
        strokeStyle: 'solid',
        strokeDasharray: [8, 4],
      })
      fallbackPolyline.setMap(map)
      routeOverlaysRef.current.push(fallbackPolyline)
    }

    const drawWalkingRoute = async (): Promise<void> => {
      if (routeStops.length < 2) {
        if (markers.length > 0) {
          map.setFitView(markers)
        } else {
          map.setCenter(origin)
        }
        return
      }

      const Walking = window.AMap.Walking
      if (!Walking) {
        drawFallbackRoute()
        map.setFitView(getFocusOverlays())
        return
      }

      const walking = new Walking({
        hideMarkers: true,
        autoFitView: false,
      })

      const mergedPath: LngLatTuple[] = []

      try {
        const [from, to] = routeStops
        const segment = await new Promise<LngLatTuple[]>((resolve, reject) => {
          walking.search(from, to, (searchStatus, result) => {
            if (searchStatus !== 'complete') {
              reject(new Error('walking search failed'))
              return
            }

            const path = extractWalkingPath(result)
            if (path.length === 0) {
              reject(new Error('walking path empty'))
              return
            }

            resolve(path)
          })
        })

        if (mergedPath.length === 0) {
          mergedPath.push(...segment)
        } else if (samePoint(mergedPath[mergedPath.length - 1], segment[0])) {
          mergedPath.push(...segment.slice(1))
        } else {
          mergedPath.push(...segment)
        }

        if (routeRequestId !== routeRequestIdRef.current) {
          return
        }

        if (mergedPath.length < 2) {
          drawFallbackRoute()
        } else {
          const polyline = new window.AMap.Polyline({
            path: mergedPath,
            strokeColor: '#FB923C',
            strokeWeight: 7,
            strokeOpacity: 0.68,
            strokeStyle: 'solid',
          })
          polyline.setMap(map)
          routeOverlaysRef.current.push(polyline)
        }
      } catch {
        drawFallbackRoute()
      } finally {
        walking.clear?.()
      }

      if (routeRequestId !== routeRequestIdRef.current) {
        return
      }

      const fitTargets = getFocusOverlays()
      if (fitTargets.length > 0) {
        map.setFitView(fitTargets)
      } else {
        map.setCenter(origin)
      }
    }

    void drawWalkingRoute()
  }, [activeId, onSelect, origin, points, status])

  if (!amapKey) {
    return (
      <div className="map-error">
        <h3>未检测到高德地图 Key</h3>
        <p>请在 `.env.local` 配置 `VITE_AMAP_KEY` 与 `VITE_AMAP_SECURITY_CODE` 后刷新页面。</p>
      </div>
    )
  }

  if (status === 'error') {
    return (
      <div className="map-error">
        <h3>地图加载失败</h3>
        <p>请检查 Key/安全密钥或网络后刷新页面。</p>
      </div>
    )
  }

  return (
    <div className="map-wrapper">
      {status === 'loading' ? <div className="map-loading">地图加载中...</div> : null}
      <div className="map-canvas" id="map-container" ref={containerRef} />
    </div>
  )
}

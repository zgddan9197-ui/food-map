import { NavLink, Outlet } from 'react-router-dom'
import { getMessageNotifications } from '../lib/me'

const linkClassName = ({ isActive }: { isActive: boolean }): string =>
  isActive ? 'top-nav__link top-nav__link--active' : 'top-nav__link'

export default function AppShell() {
  const unreadCount = getMessageNotifications().filter((item) => item.unread).length

  return (
    <div className="app-shell">
      <header className="top-nav">
        <div className="brand-block">
          <p className="brand-block__name">食刻</p>
          <p className="brand-block__tagline">此刻想吃，食刻知道</p>
        </div>
        <nav className="top-nav__links" aria-label="主导航">
          <NavLink className={linkClassName} to="/">
            找吃的
          </NavLink>
          <NavLink className={linkClassName} to="/map">
            逛吃地图
          </NavLink>
          <NavLink className={linkClassName} to="/community">
            同学在吃
          </NavLink>
          <NavLink className={linkClassName} to="/me">
            <span>我的</span>
            {unreadCount > 0 ? <span className="notif-badge">{unreadCount}</span> : null}
          </NavLink>
        </nav>
      </header>
      <main className="app-main">
        <Outlet />
      </main>
    </div>
  )
}
